#!/usr/bin/env python3
"""
AI测试日志分析器 - 主入口
Log Analyzer Pro with AI-powered search and analysis

功能:
1. 自动扫描和解析测试日志文件
2. 智能搜索 - 按时间、关键词、日志级别
3. 日志文件对比 - 高亮显示差异
4. AI辅助分析 - 使用Ollama本地模型

使用方法:
    python main.py [日志目录路径]

示例:
    python main.py /path/to/log
    python main.py  # 启动后手动选择目录
"""

import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def check_dependencies():
    """检查依赖是否安装"""
    missing = []
    
    try:
        from PyQt6.QtWidgets import QApplication
    except ImportError:
        missing.append("PyQt6")
    
    try:
        import chardet
    except ImportError:
        missing.append("chardet")
    
    # 可选依赖
    optional_missing = []
    
    try:
        from llama_index.core import Document
    except ImportError:
        optional_missing.append("llama-index")
    
    try:
        from llama_index.llms.ollama import Ollama
    except ImportError:
        optional_missing.append("llama-index-llms-ollama")
    
    if missing:
        print("❌ 缺少必要的依赖包:")
        for pkg in missing:
            print(f"   - {pkg}")
        print("\n请运行以下命令安装:")
        print(f"   pip install {' '.join(missing)}")
        return False
    
    if optional_missing:
        print("⚠️  可选依赖未安装 (AI功能可能受限):")
        for pkg in optional_missing:
            print(f"   - {pkg}")
        print("\n安装命令:")
        print(f"   pip install {' '.join(optional_missing)}")
        print()
    
    return True


def main():
    """主函数"""
    # 检查依赖
    if not check_dependencies():
        sys.exit(1)
    
    # 导入应用
    from ui.app import run_application, MainApplication
    from PyQt6.QtWidgets import QApplication
    
    # 创建应用
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    app.setApplicationName("AI Log Analyzer")
    app.setOrganizationName("LogAnalyzer")
    
    # 创建主窗口
    window = MainApplication()
    
    # 如果命令行提供了目录参数，自动加载
    if len(sys.argv) > 1:
        log_dir = sys.argv[1]
        if os.path.isdir(log_dir):
            window.load_directory(log_dir)
        else:
            print(f"⚠️  目录不存在: {log_dir}")
    
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
