"""
工具函数模块
"""

import os
import re
from datetime import datetime
from typing import List, Dict, Any, Optional
import json


def format_file_size(size: int) -> str:
    """格式化文件大小"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


def format_duration(seconds: float) -> str:
    """格式化时间长度"""
    if seconds < 60:
        return f"{seconds:.1f}秒"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}分钟"
    else:
        hours = seconds / 3600
        return f"{hours:.1f}小时"


def highlight_keywords(text: str, keywords: List[str], 
                       highlight_start: str = '<mark>',
                       highlight_end: str = '</mark>') -> str:
    """高亮关键词"""
    result = text
    for keyword in keywords:
        pattern = re.compile(re.escape(keyword), re.IGNORECASE)
        result = pattern.sub(f'{highlight_start}\\g<0>{highlight_end}', result)
    return result


def extract_timestamps(text: str) -> List[datetime]:
    """从文本中提取时间戳"""
    timestamps = []
    
    patterns = [
        (r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})', '%Y-%m-%d %H:%M:%S'),
        (r'(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})', '%Y/%m/%d %H:%M:%S'),
        (r'\[(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})\]', '%Y-%m-%dT%H:%M:%S'),
    ]
    
    for pattern, fmt in patterns:
        for match in re.finditer(pattern, text):
            try:
                ts = datetime.strptime(match.group(1), fmt)
                timestamps.append(ts)
            except ValueError:
                continue
    
    return timestamps


def group_by_time(entries: List[Any], time_field: str, 
                  interval_seconds: int = 60) -> Dict[str, List[Any]]:
    """按时间分组"""
    groups = {}
    
    for entry in entries:
        ts = getattr(entry, time_field, None)
        if ts is None:
            key = "unknown"
        else:
            # 按间隔取整
            rounded = ts.replace(second=0, microsecond=0)
            key = rounded.strftime('%Y-%m-%d %H:%M')
        
        if key not in groups:
            groups[key] = []
        groups[key].append(entry)
    
    return groups


def count_log_levels(entries: List[Any]) -> Dict[str, int]:
    """统计日志级别分布"""
    counts = {
        'DEBUG': 0,
        'INFO': 0,
        'WARN': 0,
        'ERROR': 0,
        'FATAL': 0,
        'OTHER': 0
    }
    
    for entry in entries:
        level = getattr(entry, 'level', None)
        if level:
            level = level.upper()
            if level in counts:
                counts[level] += 1
            else:
                counts['OTHER'] += 1
        else:
            counts['OTHER'] += 1
    
    return counts


def generate_summary(entries: List[Any]) -> Dict[str, Any]:
    """生成日志摘要"""
    if not entries:
        return {
            'total_lines': 0,
            'time_range': None,
            'level_distribution': {},
            'top_errors': []
        }
    
    # 时间范围
    timestamps = [e.timestamp for e in entries if hasattr(e, 'timestamp') and e.timestamp]
    time_range = None
    if timestamps:
        time_range = {
            'start': min(timestamps).isoformat(),
            'end': max(timestamps).isoformat(),
            'duration': (max(timestamps) - min(timestamps)).total_seconds()
        }
    
    # 级别分布
    level_dist = count_log_levels(entries)
    
    # 错误信息
    errors = [e for e in entries if hasattr(e, 'level') and e.level and e.level.upper() in ['ERROR', 'FATAL']]
    top_errors = [{'line': e.line_number, 'content': e.content[:200]} for e in errors[:10]]
    
    return {
        'total_lines': len(entries),
        'time_range': time_range,
        'level_distribution': level_dist,
        'top_errors': top_errors
    }


def save_config(config: Dict[str, Any], path: str):
    """保存配置"""
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def load_config(path: str) -> Dict[str, Any]:
    """加载配置"""
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {}


class LogStatistics:
    """日志统计类"""
    
    def __init__(self, entries: List[Any]):
        self.entries = entries
        self._calculate()
    
    def _calculate(self):
        """计算统计信息"""
        self.total_lines = len(self.entries)
        self.level_counts = count_log_levels(self.entries)
        
        # 时间相关
        timestamps = [e.timestamp for e in self.entries 
                     if hasattr(e, 'timestamp') and e.timestamp]
        
        if timestamps:
            self.start_time = min(timestamps)
            self.end_time = max(timestamps)
            self.duration = (self.end_time - self.start_time).total_seconds()
            self.logs_per_second = self.total_lines / max(self.duration, 1)
        else:
            self.start_time = None
            self.end_time = None
            self.duration = 0
            self.logs_per_second = 0
        
        # 错误率
        error_count = self.level_counts.get('ERROR', 0) + self.level_counts.get('FATAL', 0)
        self.error_rate = error_count / max(self.total_lines, 1)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'total_lines': self.total_lines,
            'level_counts': self.level_counts,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'duration_seconds': self.duration,
            'logs_per_second': self.logs_per_second,
            'error_rate': self.error_rate
        }
    
    def __str__(self) -> str:
        return f"""日志统计:
- 总行数: {self.total_lines}
- 时间范围: {self.start_time} - {self.end_time}
- 持续时间: {format_duration(self.duration)}
- 日志速率: {self.logs_per_second:.2f} 条/秒
- 错误率: {self.error_rate:.2%}
- 级别分布: {self.level_counts}
"""
