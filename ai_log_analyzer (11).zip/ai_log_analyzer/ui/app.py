"""
应用主窗口类
"""

import sys
import os
import re
from pathlib import Path
from typing import Optional, List

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QTabWidget, QStatusBar, QToolBar, QMenuBar, QMenu,
    QFileDialog, QMessageBox, QProgressDialog, QLabel,
    QDockWidget, QApplication, QLineEdit, QCheckBox, QPushButton
)
from PyQt6.QtCore import Qt, QSettings, QSize, QTimer
from PyQt6.QtGui import QAction, QIcon, QKeySequence, QFont

from .main_window import (
    FileTreeWidget, LogViewerWidget, DiffViewerWidget,
    ChatWidget, SearchResultsWidget, SettingsDialog, WorkerThread
)

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core import (
    LogParser, LogFile, LogAIIndexer, LogComparator, DiffResult, LogEntry, LogSearchResult
)


class MainApplication(QMainWindow):
    """主应用窗口"""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("AI测试日志分析器 - Log Analyzer Pro")
        self.setMinimumSize(1400, 900)
        
        # 初始化核心组件
        self.parser: Optional[LogParser] = None
        self.ai_indexer = LogAIIndexer()
        self.comparator = LogComparator()
        self.log_files: List[LogFile] = []
        self.current_log_file: Optional[LogFile] = None
        self.current_directory: Optional[str] = None
        
        # 设置
        self.settings = QSettings("LogAnalyzer", "AILogAnalyzer")
        
        # 初始化UI
        self.setup_ui()
        self.setup_menu()
        self.setup_toolbar()
        self.setup_statusbar()
        self.setup_shortcuts()
        
        # 应用样式
        self.apply_style()
        
        # 恢复窗口状态
        self.restore_state()
        
        # 检查AI连接
        QTimer.singleShot(1000, self.check_ai_connection)
    
    def setup_ui(self):
        """设置UI布局"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(5, 5, 5, 5)
        main_layout.setSpacing(5)
        
        # 主分割器
        main_splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # 左侧面板 - 文件树
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(5)
        
        left_header = QLabel("📁 测试日志目录")
        left_header.setStyleSheet("""
            font-size: 14px;
            font-weight: bold;
            padding: 10px;
            background-color: #313244;
            border-radius: 5px;
        """)
        left_layout.addWidget(left_header)
        
        # 全局搜索框
        search_widget = QWidget()
        search_widget.setStyleSheet("""
            QWidget {
                background-color: #313244;
                border-radius: 5px;
                padding: 5px;
            }
        """)
        search_layout = QVBoxLayout(search_widget)
        search_layout.setContentsMargins(8, 8, 8, 8)
        search_layout.setSpacing(6)
        
        # 搜索输入行
        search_input_layout = QHBoxLayout()
        
        self.global_search_input = QLineEdit()
        self.global_search_input.setPlaceholderText("🔍 全局搜索日志内容...")
        self.global_search_input.setStyleSheet("""
            QLineEdit {
                padding: 8px 12px;
                border: 1px solid #45475a;
                border-radius: 6px;
                background-color: #1e1e2e;
                color: #cdd6f4;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #89b4fa;
            }
        """)
        self.global_search_input.returnPressed.connect(self.do_global_search)
        search_input_layout.addWidget(self.global_search_input)
        
        self.global_search_btn = QPushButton("搜索")
        self.global_search_btn.setStyleSheet("""
            QPushButton {
                padding: 8px 15px;
                background-color: #89b4fa;
                color: #1e1e2e;
                border: none;
                border-radius: 6px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #74c7ec;
            }
        """)
        self.global_search_btn.clicked.connect(self.do_global_search)
        search_input_layout.addWidget(self.global_search_btn)
        
        search_layout.addLayout(search_input_layout)
        
        # 搜索选项行
        search_options_layout = QHBoxLayout()
        
        self.fuzzy_search_checkbox = QCheckBox("模糊搜索")
        self.fuzzy_search_checkbox.setToolTip("允许匹配意思相近的内容")
        self.fuzzy_search_checkbox.setStyleSheet("color: #a6adc8; font-size: 11px;")
        search_options_layout.addWidget(self.fuzzy_search_checkbox)
        
        self.case_sensitive_checkbox = QCheckBox("区分大小写")
        self.case_sensitive_checkbox.setStyleSheet("color: #a6adc8; font-size: 11px;")
        search_options_layout.addWidget(self.case_sensitive_checkbox)
        
        self.regex_search_checkbox = QCheckBox("正则表达式")
        self.regex_search_checkbox.setStyleSheet("color: #a6adc8; font-size: 11px;")
        search_options_layout.addWidget(self.regex_search_checkbox)
        
        search_options_layout.addStretch()
        search_layout.addLayout(search_options_layout)
        
        left_layout.addWidget(search_widget)
        
        self.file_tree = FileTreeWidget()
        self.file_tree.file_selected.connect(self.open_log_file)
        self.file_tree.files_selected_for_compare.connect(self.compare_files)
        self.file_tree.file_send_to_ai.connect(self.send_file_to_ai)
        left_layout.addWidget(self.file_tree)
        
        # 搜索结果
        search_header = QLabel("🔍 搜索结果")
        search_header.setStyleSheet("""
            font-size: 14px;
            font-weight: bold;
            padding: 10px;
            background-color: #313244;
            border-radius: 5px;
            margin-top: 10px;
        """)
        left_layout.addWidget(search_header)
        
        self.search_results = SearchResultsWidget()
        self.search_results.result_clicked.connect(self.goto_search_result)
        left_layout.addWidget(self.search_results)
        
        main_splitter.addWidget(left_panel)
        
        # 中间面板 - 主内容区
        center_splitter = QSplitter(Qt.Orientation.Vertical)
        
        # 标签页
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabsClosable(True)
        self.tab_widget.tabCloseRequested.connect(self.close_tab)
        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #45475a;
                border-radius: 5px;
            }
            QTabBar::tab {
                padding: 8px 16px;
                margin-right: 2px;
                background-color: #313244;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
            }
            QTabBar::tab:selected {
                background-color: #45475a;
            }
        """)
        
        # 欢迎页
        welcome_widget = self.create_welcome_widget()
        self.tab_widget.addTab(welcome_widget, "🏠 欢迎")
        
        center_splitter.addWidget(self.tab_widget)
        
        main_splitter.addWidget(center_splitter)
        
        # 右侧面板 - AI对话
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        
        right_header = QLabel("🤖 AI助手")
        right_header.setStyleSheet("""
            font-size: 14px;
            font-weight: bold;
            padding: 10px;
            background-color: #313244;
            border-radius: 5px;
        """)
        right_layout.addWidget(right_header)
        
        self.chat_widget = ChatWidget(self.ai_indexer)
        self.chat_widget.request_open_file.connect(self.open_log_file)
        right_layout.addWidget(self.chat_widget)
        
        main_splitter.addWidget(right_panel)
        
        # 设置分割比例
        main_splitter.setSizes([300, 800, 350])
        
        main_layout.addWidget(main_splitter)
    
    def create_welcome_widget(self) -> QWidget:
        """创建欢迎页面"""
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        title = QLabel("🔬 AI测试日志分析器")
        title.setStyleSheet("""
            font-size: 32px;
            font-weight: bold;
            color: #89b4fa;
            margin-bottom: 20px;
        """)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)
        
        subtitle = QLabel("智能日志分析 · 快速定位问题 · AI辅助诊断")
        subtitle.setStyleSheet("""
            font-size: 16px;
            color: #a6adc8;
            margin-bottom: 40px;
        """)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle)
        
        # 功能介绍
        features = [
            ("📂", "打开日志目录", "支持多层级目录结构，自动扫描日志文件"),
            ("🔍", "智能搜索", "按时间、关键词、日志级别搜索"),
            ("📊", "对比分析", "并排对比两个日志文件，高亮差异"),
            ("🤖", "AI问答", "使用本地Ollama模型分析日志"),
        ]
        
        for icon, title_text, desc in features:
            feature_widget = QLabel(f"{icon} <b>{title_text}</b><br><span style='color:#6c7086'>{desc}</span>")
            feature_widget.setStyleSheet("""
                padding: 15px;
                background-color: #313244;
                border-radius: 10px;
                margin: 5px 50px;
            """)
            feature_widget.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(feature_widget)
        
        # 快速开始
        start_label = QLabel("按 <b>Ctrl+O</b> 打开日志目录开始分析")
        start_label.setStyleSheet("""
            margin-top: 30px;
            color: #fab387;
            font-size: 14px;
        """)
        start_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(start_label)
        
        return widget
    
    def setup_menu(self):
        """设置菜单栏"""
        menubar = self.menuBar()
        
        # 文件菜单
        file_menu = menubar.addMenu("文件(&F)")
        
        open_action = QAction("打开目录(&O)...", self)
        open_action.setShortcut(QKeySequence.StandardKey.Open)
        open_action.triggered.connect(self.open_directory)
        file_menu.addAction(open_action)
        
        open_archive_action = QAction("打开压缩包(&A)...", self)
        open_archive_action.setShortcut("Ctrl+Shift+O")
        open_archive_action.triggered.connect(self.open_archive)
        file_menu.addAction(open_archive_action)
        
        file_menu.addSeparator()
        
        refresh_action = QAction("刷新(&R)", self)
        refresh_action.setShortcut(QKeySequence.StandardKey.Refresh)
        refresh_action.triggered.connect(self.refresh_directory)
        file_menu.addAction(refresh_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("退出(&X)", self)
        exit_action.setShortcut(QKeySequence.StandardKey.Quit)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # 编辑菜单
        edit_menu = menubar.addMenu("编辑(&E)")
        
        search_action = QAction("搜索(&S)...", self)
        search_action.setShortcut(QKeySequence.StandardKey.Find)
        search_action.triggered.connect(self.show_search_dialog)
        edit_menu.addAction(search_action)
        
        # 视图菜单
        view_menu = menubar.addMenu("视图(&V)")
        
        # 工具菜单
        tools_menu = menubar.addMenu("工具(&T)")
        
        compare_action = QAction("对比文件(&C)...", self)
        compare_action.triggered.connect(self.show_compare_dialog)
        tools_menu.addAction(compare_action)
        
        tools_menu.addSeparator()
        
        find_errors_action = QAction("查找所有错误(&E)", self)
        find_errors_action.triggered.connect(self.find_all_errors)
        tools_menu.addAction(find_errors_action)
        
        tools_menu.addSeparator()
        
        settings_action = QAction("设置(&S)...", self)
        settings_action.triggered.connect(self.show_settings)
        tools_menu.addAction(settings_action)
        
        # 帮助菜单
        help_menu = menubar.addMenu("帮助(&H)")
        
        about_action = QAction("关于(&A)", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def setup_toolbar(self):
        """设置工具栏"""
        toolbar = QToolBar("主工具栏")
        toolbar.setIconSize(QSize(24, 24))
        toolbar.setMovable(False)
        self.addToolBar(toolbar)
        
        # 打开目录
        open_btn = QAction("📂 打开目录", self)
        open_btn.triggered.connect(self.open_directory)
        toolbar.addAction(open_btn)
        
        # 打开压缩包
        open_archive_btn = QAction("📦 打开压缩包", self)
        open_archive_btn.triggered.connect(self.open_archive)
        toolbar.addAction(open_archive_btn)
        
        # 刷新
        refresh_btn = QAction("🔄 刷新", self)
        refresh_btn.triggered.connect(self.refresh_directory)
        toolbar.addAction(refresh_btn)
        
        toolbar.addSeparator()
        
        # 搜索
        search_btn = QAction("🔍 搜索", self)
        search_btn.triggered.connect(self.show_search_dialog)
        toolbar.addAction(search_btn)
        
        # 对比
        compare_btn = QAction("📊 对比", self)
        compare_btn.triggered.connect(self.show_compare_dialog)
        toolbar.addAction(compare_btn)
        
        toolbar.addSeparator()
        
        # 查找错误
        errors_btn = QAction("❌ 查找错误", self)
        errors_btn.triggered.connect(self.find_all_errors)
        toolbar.addAction(errors_btn)
        
        toolbar.addSeparator()
        
        # AI索引
        index_btn = QAction("🧠 建立AI索引", self)
        index_btn.triggered.connect(self.build_ai_index)
        toolbar.addAction(index_btn)
    
    def setup_statusbar(self):
        """设置状态栏"""
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        
        self.status_label = QLabel("就绪")
        self.statusbar.addWidget(self.status_label, 1)
        
        self.files_label = QLabel("文件: 0")
        self.statusbar.addPermanentWidget(self.files_label)
        
        self.ai_status = QLabel("AI: 未连接")
        self.ai_status.setStyleSheet("color: #f38ba8;")
        self.statusbar.addPermanentWidget(self.ai_status)
    
    def setup_shortcuts(self):
        """设置快捷键"""
        pass  # 已在菜单中设置
    
    def apply_style(self):
        """应用样式"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1e1e2e;
            }
            QWidget {
                background-color: #1e1e2e;
                color: #cdd6f4;
            }
            QMenuBar {
                background-color: #181825;
                color: #cdd6f4;
                padding: 5px;
            }
            QMenuBar::item:selected {
                background-color: #45475a;
            }
            QMenu {
                background-color: #313244;
                color: #cdd6f4;
                border: 1px solid #45475a;
            }
            QMenu::item:selected {
                background-color: #45475a;
            }
            QToolBar {
                background-color: #181825;
                border: none;
                padding: 5px;
                spacing: 5px;
            }
            QToolBar QToolButton {
                background-color: transparent;
                border: none;
                padding: 8px 12px;
                border-radius: 5px;
            }
            QToolBar QToolButton:hover {
                background-color: #45475a;
            }
            QStatusBar {
                background-color: #181825;
                color: #a6adc8;
            }
            QSplitter::handle {
                background-color: #45475a;
            }
            QScrollBar:vertical {
                background-color: #1e1e2e;
                width: 12px;
            }
            QScrollBar::handle:vertical {
                background-color: #45475a;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
            QTreeWidget {
                background-color: #1e1e2e;
                border: 1px solid #45475a;
                border-radius: 5px;
            }
            QTreeWidget::item {
                padding: 5px;
            }
            QTreeWidget::item:selected {
                background-color: #45475a;
            }
            QTreeWidget::item:hover {
                background-color: #313244;
            }
            QPushButton {
                padding: 8px 16px;
                background-color: #45475a;
                border: none;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #585b70;
            }
            QPushButton:pressed {
                background-color: #313244;
            }
            QLineEdit {
                padding: 8px;
                background-color: #313244;
                border: 1px solid #45475a;
                border-radius: 5px;
            }
            QLineEdit:focus {
                border-color: #89b4fa;
            }
            QComboBox {
                padding: 8px;
                background-color: #313244;
                border: 1px solid #45475a;
                border-radius: 5px;
            }
            QProgressBar {
                background-color: #313244;
                border: none;
                border-radius: 5px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #89b4fa;
                border-radius: 5px;
            }
        """)
    
    def restore_state(self):
        """恢复窗口状态"""
        geometry = self.settings.value("geometry")
        if geometry:
            self.restoreGeometry(geometry)
        
        state = self.settings.value("windowState")
        if state:
            self.restoreState(state)
    
    def closeEvent(self, event):
        """关闭事件"""
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("windowState", self.saveState())
        event.accept()
    
    def check_ai_connection(self):
        """检查AI连接状态"""
        if self.ai_indexer.check_ollama_connection():
            self.ai_status.setText("AI: 已连接 ✓")
            self.ai_status.setStyleSheet("color: #a6e3a1;")
        else:
            self.ai_status.setText("AI: 未连接")
            self.ai_status.setStyleSheet("color: #f38ba8;")
    
    def open_directory(self):
        """打开日志目录"""
        directory = QFileDialog.getExistingDirectory(
            self, "选择日志目录", "",
            QFileDialog.Option.ShowDirsOnly
        )
        
        if directory:
            self.load_directory(directory)
    
    def open_archive(self):
        """打开压缩包"""
        from core import extract_archive, extract_all_archives, ARCHIVE_EXTENSIONS
        
        # 构建文件过滤器
        ext_list = ' '.join(f'*{ext}' for ext in ARCHIVE_EXTENSIONS)
        file_path, _ = QFileDialog.getOpenFileName(
            self, "选择压缩包",
            "",
            f"压缩文件 ({ext_list});;所有文件 (*.*)"
        )
        
        if not file_path:
            return
        
        file_path = Path(file_path)
        
        # 创建临时解压目录
        import tempfile
        extract_dir = Path(tempfile.mkdtemp(prefix="log_analyzer_"))
        
        # 解压主压缩包
        progress = QProgressDialog("正在解压压缩包...", "取消", 0, 0, self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.show()
        QApplication.processEvents()
        
        if not extract_archive(file_path, extract_dir):
            progress.close()
            QMessageBox.critical(self, "错误", f"无法解压文件: {file_path.name}")
            return
        
        # 递归解压所有嵌套的压缩包
        progress.setLabelText("正在解压嵌套压缩包...")
        QApplication.processEvents()
        
        extracted_count = extract_all_archives(extract_dir, delete_after=True)
        
        progress.close()
        
        if extracted_count > 0:
            self.status_label.setText(f"已解压 {extracted_count + 1} 个压缩包")
        
        # 加载解压后的目录
        self.load_directory(str(extract_dir))
        
        # 记录临时目录，退出时清理
        if not hasattr(self, '_temp_dirs'):
            self._temp_dirs = []
        self._temp_dirs.append(extract_dir)
    
    def load_directory(self, directory: str):
        """加载目录"""
        from core import extract_all_archives
        
        self.parser = LogParser(directory)
        self.current_directory = directory  # 保存当前目录
        self.status_label.setText(f"正在扫描目录: {directory}")
        
        # 检查并解压目录中的压缩包
        progress = QProgressDialog("正在检查并解压压缩包...", "取消", 0, 0, self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.show()
        QApplication.processEvents()
        
        extracted = extract_all_archives(Path(directory), delete_after=True)
        if extracted > 0:
            self.status_label.setText(f"已解压 {extracted} 个压缩包")
        
        progress.close()
        
        # 扫描文件
        progress = QProgressDialog("正在扫描日志文件...", "取消", 0, 0, self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        progress.show()
        
        QApplication.processEvents()
        
        self.log_files = self.parser.scan_directory()
        
        progress.close()
        
        if not self.log_files:
            QMessageBox.warning(self, "警告", "未找到日志文件")
            return
        
        # 解析日志文件
        progress = QProgressDialog("正在解析日志文件...", "取消", 0, len(self.log_files), self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        
        for i, log_file in enumerate(self.log_files):
            if progress.wasCanceled():
                break
            progress.setValue(i)
            progress.setLabelText(f"正在解析: {log_file.name}")
            QApplication.processEvents()
            
            self.parser.parse_log_file(log_file)
        
        progress.close()
        
        # 更新UI
        self.file_tree.load_log_files(self.log_files)
        self.files_label.setText(f"文件: {len(self.log_files)}")
        self.status_label.setText(f"已加载 {len(self.log_files)} 个日志文件")
        
        # 更新AI索引器的日志文件引用
        self.ai_indexer.log_files = {lf.path: lf for lf in self.log_files}
        
        # 更新ChatWidget的目录上下文
        self.chat_widget.set_directory_context(directory, self.log_files)
        
        # 保存最近目录
        self.settings.setValue("lastDirectory", directory)
    
    def refresh_directory(self):
        """刷新目录"""
        if self.parser:
            self.load_directory(self.parser.base_path)
    
    def open_log_file(self, file_path: str):
        """打开日志文件"""
        log_file = self.file_tree.log_files.get(file_path)
        if not log_file:
            return
        
        self.current_log_file = log_file
        
        # 检查是否已打开（使用完整路径作为唯一标识）
        for i in range(self.tab_widget.count()):
            if self.tab_widget.tabToolTip(i) == file_path:
                self.tab_widget.setCurrentIndex(i)
                # 更新ChatWidget的当前文件（即使已打开也更新）
                self._update_chat_current_file(log_file)
                return
        
        # 创建新的查看器
        viewer = LogViewerWidget()
        viewer.load_file(log_file)
        
        # 添加标签页 - 使用 test_case/name 格式以区分不同目录的同名文件
        tab_title = f"📄 {log_file.test_case}/{log_file.name}"
        index = self.tab_widget.addTab(viewer, tab_title)
        self.tab_widget.setTabToolTip(index, file_path)  # 完整路径作为tooltip
        self.tab_widget.setCurrentIndex(index)
        
        # 更新ChatWidget的当前文件
        self._update_chat_current_file(log_file)
    
    def _update_chat_current_file(self, log_file: LogFile):
        """更新ChatWidget的当前分析文件"""
        # 读取文件内容
        content = ""
        for entry in log_file.entries:
            content += entry.content + "\n"
        
        if not content:
            # 如果entries为空，直接读取文件
            try:
                with open(log_file.path, 'r', encoding=log_file.encoding, errors='replace') as f:
                    content = f.read()
            except:
                pass
        
        self.chat_widget.set_current_file(log_file.path, content)
    
    def close_tab(self, index: int):
        """关闭标签页"""
        if index > 0:  # 不关闭欢迎页
            self.tab_widget.removeTab(index)
    
    def compare_files(self, paths: List[str]):
        """多日志同步查看"""
        if len(paths) < 1:
            return
        
        # 收集所有有效的日志文件
        log_files = []
        for path in paths[:4]:  # 最多4个
            log_file = self.file_tree.log_files.get(path)
            if log_file:
                log_files.append(log_file)
        
        if not log_files:
            return
        
        # 创建多日志同步查看器
        from .main_window import MultiLogSyncViewer
        viewer = MultiLogSyncViewer()
        viewer.load_files(log_files)
        
        # 生成标签名 - 使用 test_case/name 格式
        if len(log_files) == 1:
            tab_name = f"📊 查看: {log_files[0].test_case}/{log_files[0].name}"
        elif len(log_files) == 2:
            name1 = f"{log_files[0].test_case}/{log_files[0].name}"
            name2 = f"{log_files[1].test_case}/{log_files[1].name}"
            tab_name = f"📊 对比: {name1} ↔ {name2}"
        else:
            tab_name = f"📊 多日志对比 ({len(log_files)}个)"
        
        # 添加标签页
        index = self.tab_widget.addTab(viewer, tab_name)
        self.tab_widget.setCurrentIndex(index)
    
    def show_add_log_dialog(self, viewer):
        """显示添加日志对话框（供MultiLogSyncViewer调用）"""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QListWidget, QDialogButtonBox, QListWidgetItem
        
        dialog = QDialog(self)
        dialog.setWindowTitle("选择要添加的日志文件")
        dialog.setMinimumSize(400, 300)
        
        layout = QVBoxLayout(dialog)
        
        # 文件列表 - 显示 test_case/log_folder/name 格式以区分同名文件
        list_widget = QListWidget()
        for path, log_file in self.file_tree.log_files.items():
            display_name = f"📄 {log_file.test_case}/{log_file.log_folder}/{log_file.name}"
            item = QListWidgetItem(display_name)
            item.setData(Qt.ItemDataRole.UserRole, path)
            item.setToolTip(path)
            list_widget.addItem(item)
        
        layout.addWidget(list_widget)
        
        # 按钮
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            selected = list_widget.currentItem()
            if selected:
                path = selected.data(Qt.ItemDataRole.UserRole)
                log_file = self.file_tree.log_files.get(path)
                if log_file:
                    viewer.add_log_file(log_file)
    
    def send_file_to_ai(self, file_path: str):
        """发送文件到AI分析"""
        log_file = self.file_tree.log_files.get(file_path)
        if not log_file:
            return
        
        # 首先打开文件
        self.open_log_file(file_path)
        
        # 更新ChatWidget的当前文件
        self._update_chat_current_file(log_file)
        
        # 显示提示
        from PyQt6.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self, 
            "AI分析", 
            f"已选择文件: {log_file.name}\n\n是否立即让AI分析此文件的错误和问题？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            # 自动发送分析请求
            self.chat_widget.send_message("请分析这个日志文件，找出所有的错误、警告和潜在问题，并给出修复建议。")
    
    def show_search_dialog(self):
        """显示搜索对话框 - 聚焦到全局搜索框"""
        self.global_search_input.setFocus()
        self.global_search_input.selectAll()
    
    def do_global_search(self):
        """执行全局搜索"""
        keyword = self.global_search_input.text().strip()
        if not keyword:
            return
        
        if not self.log_files:
            QMessageBox.information(self, "提示", "请先加载日志目录")
            return
        
        # 获取搜索选项
        is_fuzzy = self.fuzzy_search_checkbox.isChecked()
        is_case_sensitive = self.case_sensitive_checkbox.isChecked()
        is_regex = self.regex_search_checkbox.isChecked()
        
        # 显示搜索进度
        self.status_label.setText(f"正在搜索 '{keyword}'...")
        QApplication.processEvents()
        
        results = []
        
        # 构建搜索模式
        if is_regex:
            try:
                flags = 0 if is_case_sensitive else re.IGNORECASE
                pattern = re.compile(keyword, flags)
            except re.error:
                QMessageBox.warning(self, "错误", "无效的正则表达式")
                return
        elif is_fuzzy:
            # 模糊搜索：在每个字符之间插入.*?
            escaped = [re.escape(c) for c in keyword]
            pattern_str = '.*?'.join(escaped)
            flags = 0 if is_case_sensitive else re.IGNORECASE
            pattern = re.compile(pattern_str, flags)
        else:
            pattern = None
        
        # 搜索所有日志文件
        max_results_per_file = 100  # 每个文件最多显示的结果数
        total_results = 0
        
        for log_file in self.log_files:
            file_results = 0
            
            # 优先使用已解析的entries
            if log_file.entries:
                for entry in log_file.entries:
                    if file_results >= max_results_per_file:
                        break
                    
                    matched = False
                    
                    if is_regex or is_fuzzy:
                        match = pattern.search(entry.content)
                        if match:
                            matched = True
                    else:
                        # 普通搜索
                        if is_case_sensitive:
                            if keyword in entry.content:
                                matched = True
                        else:
                            if keyword.lower() in entry.content.lower():
                                matched = True
                    
                    if matched:
                        result = LogSearchResult(
                            entry=entry,
                            score=1.0
                        )
                        results.append(result)
                        file_results += 1
                        total_results += 1
            else:
                # 直接读取文件搜索
                try:
                    with open(log_file.path, 'r', encoding=log_file.encoding, errors='replace') as f:
                        for line_num, line in enumerate(f, 1):
                            if file_results >= max_results_per_file:
                                break
                            
                            line = line.rstrip('\n\r')
                            matched = False
                            
                            if is_regex or is_fuzzy:
                                match = pattern.search(line)
                                if match:
                                    matched = True
                            else:
                                if is_case_sensitive:
                                    if keyword in line:
                                        matched = True
                                else:
                                    if keyword.lower() in line.lower():
                                        matched = True
                            
                            if matched:
                                entry = LogEntry(
                                    line_number=line_num,
                                    content=line,
                                    level=self._detect_level(line),
                                    file_path=log_file.path
                                )
                                result = LogSearchResult(
                                    entry=entry,
                                    score=1.0
                                )
                                results.append(result)
                                file_results += 1
                                total_results += 1
                except Exception as e:
                    print(f"读取文件失败 {log_file.path}: {e}")
            
            # 限制总结果数
            if total_results >= 500:
                break
        
        # 显示结果
        self.search_results.show_results(results, keyword)
        
        if total_results >= 500:
            self.status_label.setText(f"找到 500+ 条结果（已截断），关键词: '{keyword}'")
        else:
            self.status_label.setText(f"找到 {len(results)} 条结果，关键词: '{keyword}'")
    
    def _detect_level(self, line: str) -> Optional[str]:
        """检测日志级别"""
        line_upper = line.upper()
        for level in ['FATAL', 'ERROR', 'WARN', 'WARNING', 'INFO', 'DEBUG', 'TRACE']:
            if level in line_upper:
                return level.replace('WARNING', 'WARN')
        return None
    
    def search_logs(self, keyword: str):
        """搜索日志（兼容旧接口）"""
        self.global_search_input.setText(keyword)
        self.do_global_search()
    
    def goto_search_result(self, file_path: str, line_number: int):
        """跳转到搜索结果"""
        self.open_log_file(file_path)
        
        # 延迟执行跳转，确保文件已加载
        def do_jump():
            for i in range(self.tab_widget.count()):
                if self.tab_widget.tabToolTip(i) == file_path:
                    self.tab_widget.setCurrentIndex(i)
                    widget = self.tab_widget.widget(i)
                    if isinstance(widget, LogViewerWidget):
                        widget.goto_line_number(line_number)
                    break
        
        QTimer.singleShot(200, do_jump)
    
    def show_compare_dialog(self):
        """显示对比对话框"""
        selected = self.file_tree.selectedItems()
        paths = [item.data(0, Qt.ItemDataRole.UserRole) 
                for item in selected if item.data(0, Qt.ItemDataRole.UserRole)]
        
        if len(paths) >= 2:
            self.compare_files(paths[:2])
        else:
            QMessageBox.information(self, "提示", "请在左侧文件树中选择两个文件进行对比")
    
    def find_all_errors(self):
        """查找所有错误"""
        results = self.ai_indexer.find_errors()
        self.search_results.show_results(results)
        self.status_label.setText(f"找到 {len(results)} 个错误")
    
    def build_ai_index(self):
        """建立AI索引"""
        if not self.log_files:
            QMessageBox.warning(self, "警告", "请先加载日志文件")
            return
        
        progress = QProgressDialog("正在建立AI索引...", "取消", 0, len(self.log_files), self)
        progress.setWindowModality(Qt.WindowModality.WindowModal)
        
        def update_progress(current, total, msg):
            progress.setValue(current)
            progress.setLabelText(msg)
            QApplication.processEvents()
        
        success = self.ai_indexer.index_log_files(self.log_files, update_progress)
        
        progress.close()
        
        if success:
            self.status_label.setText("AI索引建立完成")
            QMessageBox.information(self, "完成", "AI索引建立完成！现在可以使用智能搜索功能。")
        else:
            QMessageBox.warning(self, "警告", "AI索引建立失败")
    
    def show_settings(self):
        """显示设置对话框"""
        dialog = SettingsDialog(self)
        if dialog.exec():
            # 应用设置
            pass
    
    def show_about(self):
        """显示关于对话框"""
        QMessageBox.about(
            self,
            "关于",
            """<h2>AI测试日志分析器</h2>
            <p>版本: 1.0.0</p>
            <p>一款基于AI的测试日志分析工具</p>
            <hr>
            <p><b>功能特性:</b></p>
            <ul>
                <li>自动扫描和解析日志文件</li>
                <li>智能搜索和定位</li>
                <li>日志文件对比</li>
                <li>AI辅助分析(Ollama + Qwen3)</li>
            </ul>
            <hr>
            <p>使用 PyQt6 + LlamaIndex 构建</p>
            """
        )
    
    def closeEvent(self, event):
        """关闭事件，清理临时目录"""
        # 清理临时解压目录
        if hasattr(self, '_temp_dirs'):
            import shutil
            for temp_dir in self._temp_dirs:
                try:
                    if temp_dir.exists():
                        shutil.rmtree(temp_dir)
                except Exception as e:
                    print(f"清理临时目录失败: {e}")
        
        # 保存窗口状态
        self.save_state()
        event.accept()


def run_application():
    """运行应用程序"""
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    
    # 设置应用信息
    app.setApplicationName("AI Log Analyzer")
    app.setOrganizationName("LogAnalyzer")
    
    window = MainApplication()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    run_application()
