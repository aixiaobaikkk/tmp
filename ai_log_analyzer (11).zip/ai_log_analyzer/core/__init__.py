"""
Core module - 核心功能模块
"""

from .log_parser import (
    LogParser, LogFile, LogEntry, LogSearchResult,
    extract_archive, extract_all_archives, ARCHIVE_EXTENSIONS
)
from .ai_indexer import LogAIIndexer, AISearchResult, OllamaChat
from .comparator import LogComparator, DiffResult, DiffLine, DiffType, DiffBlock

__all__ = [
    'LogParser', 'LogFile', 'LogEntry', 'LogSearchResult',
    'extract_archive', 'extract_all_archives', 'ARCHIVE_EXTENSIONS',
    'LogAIIndexer', 'AISearchResult', 'OllamaChat',
    'LogComparator', 'DiffResult', 'DiffLine', 'DiffType', 'DiffBlock'
]
