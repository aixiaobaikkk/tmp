"""
日志对比模块 - 实现日志文件的差异对比
"""

import difflib
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
from .log_parser import LogFile, LogEntry


class DiffType(Enum):
    """差异类型"""
    EQUAL = 'equal'
    INSERT = 'insert'
    DELETE = 'delete'
    REPLACE = 'replace'


@dataclass
class DiffLine:
    """差异行"""
    line_number_left: Optional[int]
    line_number_right: Optional[int]
    content_left: str
    content_right: str
    diff_type: DiffType
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'line_number_left': self.line_number_left,
            'line_number_right': self.line_number_right,
            'content_left': self.content_left,
            'content_right': self.content_right,
            'diff_type': self.diff_type.value
        }


@dataclass
class DiffBlock:
    """差异块"""
    start_line_left: int
    start_line_right: int
    lines: List[DiffLine]
    diff_type: DiffType
    
    @property
    def is_different(self) -> bool:
        return self.diff_type != DiffType.EQUAL


@dataclass
class DiffResult:
    """对比结果"""
    left_file: str
    right_file: str
    blocks: List[DiffBlock]
    similarity: float
    total_lines_left: int
    total_lines_right: int
    added_lines: int
    deleted_lines: int
    modified_lines: int
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'left_file': self.left_file,
            'right_file': self.right_file,
            'similarity': self.similarity,
            'total_lines_left': self.total_lines_left,
            'total_lines_right': self.total_lines_right,
            'added_lines': self.added_lines,
            'deleted_lines': self.deleted_lines,
            'modified_lines': self.modified_lines
        }


class LogComparator:
    """日志对比器"""
    
    def __init__(self, context_lines: int = 3):
        self.context_lines = context_lines
    
    def compare_files(self, left_file: LogFile, right_file: LogFile) -> DiffResult:
        """对比两个日志文件"""
        left_lines = [e.content for e in left_file.entries]
        right_lines = [e.content for e in right_file.entries]
        
        return self.compare_lines(
            left_lines, right_lines,
            left_file.path, right_file.path
        )
    
    def compare_lines(self, left_lines: List[str], right_lines: List[str],
                      left_name: str = "left", right_name: str = "right") -> DiffResult:
        """对比两个文本行列表"""
        # 使用SequenceMatcher计算差异
        matcher = difflib.SequenceMatcher(None, left_lines, right_lines)
        
        blocks = []
        added = 0
        deleted = 0
        modified = 0
        
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            diff_lines = []
            
            if tag == 'equal':
                # 相同的行
                for i, j in zip(range(i1, i2), range(j1, j2)):
                    diff_lines.append(DiffLine(
                        line_number_left=i + 1,
                        line_number_right=j + 1,
                        content_left=left_lines[i],
                        content_right=right_lines[j],
                        diff_type=DiffType.EQUAL
                    ))
                diff_type = DiffType.EQUAL
                
            elif tag == 'replace':
                # 替换的行
                max_len = max(i2 - i1, j2 - j1)
                for k in range(max_len):
                    left_idx = i1 + k if k < (i2 - i1) else None
                    right_idx = j1 + k if k < (j2 - j1) else None
                    
                    diff_lines.append(DiffLine(
                        line_number_left=left_idx + 1 if left_idx is not None else None,
                        line_number_right=right_idx + 1 if right_idx is not None else None,
                        content_left=left_lines[left_idx] if left_idx is not None else '',
                        content_right=right_lines[right_idx] if right_idx is not None else '',
                        diff_type=DiffType.REPLACE
                    ))
                modified += max_len
                diff_type = DiffType.REPLACE
                
            elif tag == 'delete':
                # 删除的行
                for i in range(i1, i2):
                    diff_lines.append(DiffLine(
                        line_number_left=i + 1,
                        line_number_right=None,
                        content_left=left_lines[i],
                        content_right='',
                        diff_type=DiffType.DELETE
                    ))
                deleted += (i2 - i1)
                diff_type = DiffType.DELETE
                
            elif tag == 'insert':
                # 插入的行
                for j in range(j1, j2):
                    diff_lines.append(DiffLine(
                        line_number_left=None,
                        line_number_right=j + 1,
                        content_left='',
                        content_right=right_lines[j],
                        diff_type=DiffType.INSERT
                    ))
                added += (j2 - j1)
                diff_type = DiffType.INSERT
            
            if diff_lines:
                blocks.append(DiffBlock(
                    start_line_left=i1 + 1,
                    start_line_right=j1 + 1,
                    lines=diff_lines,
                    diff_type=diff_type
                ))
        
        # 计算相似度
        similarity = matcher.ratio()
        
        return DiffResult(
            left_file=left_name,
            right_file=right_name,
            blocks=blocks,
            similarity=similarity,
            total_lines_left=len(left_lines),
            total_lines_right=len(right_lines),
            added_lines=added,
            deleted_lines=deleted,
            modified_lines=modified
        )
    
    def get_unified_diff(self, left_file: LogFile, right_file: LogFile,
                         context_lines: int = 3) -> str:
        """生成统一格式的diff"""
        left_lines = [e.content + '\n' for e in left_file.entries]
        right_lines = [e.content + '\n' for e in right_file.entries]
        
        diff = difflib.unified_diff(
            left_lines, right_lines,
            fromfile=left_file.path,
            tofile=right_file.path,
            n=context_lines
        )
        
        return ''.join(diff)
    
    def get_html_diff(self, left_file: LogFile, right_file: LogFile) -> str:
        """生成HTML格式的差异"""
        left_lines = [e.content for e in left_file.entries]
        right_lines = [e.content for e in right_file.entries]
        
        differ = difflib.HtmlDiff(wrapcolumn=80)
        html = differ.make_file(
            left_lines, right_lines,
            fromdesc=left_file.name,
            todesc=right_file.name,
            context=True,
            numlines=self.context_lines
        )
        
        return html
    
    def find_common_differences(self, files: List[LogFile]) -> Dict[str, List[DiffLine]]:
        """找出多个文件中的共同差异"""
        if len(files) < 2:
            return {}
        
        # 以第一个文件为基准
        base_file = files[0]
        common_diffs = {}
        
        for other_file in files[1:]:
            result = self.compare_files(base_file, other_file)
            
            for block in result.blocks:
                if block.is_different:
                    for line in block.lines:
                        key = f"{line.line_number_left or 0}:{line.content_left[:50]}"
                        if key not in common_diffs:
                            common_diffs[key] = []
                        common_diffs[key].append(line)
        
        return common_diffs
    
    def compare_by_timestamp(self, left_file: LogFile, right_file: LogFile) -> DiffResult:
        """按时间戳对齐后对比"""
        # 收集有时间戳的条目
        left_timed = [(e.timestamp, e) for e in left_file.entries if e.timestamp]
        right_timed = [(e.timestamp, e) for e in right_file.entries if e.timestamp]
        
        if not left_timed or not right_timed:
            # 如果没有足够的时间戳，回退到普通对比
            return self.compare_files(left_file, right_file)
        
        # 按时间排序
        left_timed.sort(key=lambda x: x[0])
        right_timed.sort(key=lambda x: x[0])
        
        # 对齐时间戳
        aligned_left = []
        aligned_right = []
        
        i, j = 0, 0
        while i < len(left_timed) and j < len(right_timed):
            lt, le = left_timed[i]
            rt, re = right_timed[j]
            
            time_diff = abs((lt - rt).total_seconds())
            
            if time_diff < 1:  # 1秒内认为是同一时间点
                aligned_left.append(le.content)
                aligned_right.append(re.content)
                i += 1
                j += 1
            elif lt < rt:
                aligned_left.append(le.content)
                aligned_right.append('')
                i += 1
            else:
                aligned_left.append('')
                aligned_right.append(re.content)
                j += 1
        
        # 添加剩余的行
        while i < len(left_timed):
            aligned_left.append(left_timed[i][1].content)
            aligned_right.append('')
            i += 1
            
        while j < len(right_timed):
            aligned_left.append('')
            aligned_right.append(right_timed[j][1].content)
            j += 1
        
        return self.compare_lines(
            aligned_left, aligned_right,
            left_file.path, right_file.path
        )


class InlineDiffHighlighter:
    """行内差异高亮器"""
    
    @staticmethod
    def get_char_diff(left: str, right: str) -> Tuple[List[Tuple[str, str]], List[Tuple[str, str]]]:
        """获取字符级别的差异"""
        matcher = difflib.SequenceMatcher(None, left, right)
        
        left_parts = []
        right_parts = []
        
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                left_parts.append(('equal', left[i1:i2]))
                right_parts.append(('equal', right[j1:j2]))
            elif tag == 'replace':
                left_parts.append(('delete', left[i1:i2]))
                right_parts.append(('insert', right[j1:j2]))
            elif tag == 'delete':
                left_parts.append(('delete', left[i1:i2]))
            elif tag == 'insert':
                right_parts.append(('insert', right[j1:j2]))
        
        return left_parts, right_parts
    
    @staticmethod
    def highlight_word_diff(left: str, right: str) -> Tuple[str, str]:
        """词级别的差异高亮（返回HTML）"""
        left_words = left.split()
        right_words = right.split()
        
        matcher = difflib.SequenceMatcher(None, left_words, right_words)
        
        left_html = []
        right_html = []
        
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                left_html.append(' '.join(left_words[i1:i2]))
                right_html.append(' '.join(right_words[j1:j2]))
            elif tag == 'replace':
                left_html.append(f'<span class="diff-delete">{" ".join(left_words[i1:i2])}</span>')
                right_html.append(f'<span class="diff-insert">{" ".join(right_words[j1:j2])}</span>')
            elif tag == 'delete':
                left_html.append(f'<span class="diff-delete">{" ".join(left_words[i1:i2])}</span>')
            elif tag == 'insert':
                right_html.append(f'<span class="diff-insert">{" ".join(right_words[j1:j2])}</span>')
        
        return ' '.join(left_html), ' '.join(right_html)
