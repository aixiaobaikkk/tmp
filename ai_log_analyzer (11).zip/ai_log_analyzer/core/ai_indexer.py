"""
AI索引和检索模块 - 使用LlamaIndex和Ollama
"""

import os
import json
from typing import List, Dict, Any, Optional
from pathlib import Path
from dataclasses import dataclass
import asyncio

# LlamaIndex imports
try:
    from llama_index.core import (
        Document,
        VectorStoreIndex,
        Settings,
        StorageContext,
        load_index_from_storage
    )
    from llama_index.core.node_parser import SentenceSplitter
    from llama_index.llms.ollama import Ollama
    from llama_index.embeddings.huggingface import HuggingFaceEmbedding
    LLAMA_INDEX_AVAILABLE = True
except ImportError:
    LLAMA_INDEX_AVAILABLE = False
    print("Warning: LlamaIndex not installed. AI features will be limited.")

from .log_parser import LogFile, LogEntry, LogParser, LogSearchResult


@dataclass
class AISearchResult:
    """AI搜索结果"""
    answer: str
    source_entries: List[LogEntry]
    confidence: float
    related_files: List[str]
    

class LogAIIndexer:
    """日志AI索引器"""
    
    def __init__(self, 
                 model_name: str = "qwen3:latest",
                 ollama_base_url: str = "http://localhost:11434",
                 embed_model_name: str = "BAAI/bge-small-zh-v1.5"):
        self.model_name = model_name
        self.ollama_base_url = ollama_base_url
        self.embed_model_name = embed_model_name
        self.index = None
        self.documents = []
        self.log_files: Dict[str, LogFile] = {}
        self.entry_mapping: Dict[str, LogEntry] = {}
        self._initialized = False
        
    def initialize(self) -> bool:
        """初始化AI组件"""
        if not LLAMA_INDEX_AVAILABLE:
            print("LlamaIndex not available")
            return False
            
        try:
            # 配置LLM
            llm = Ollama(
                model=self.model_name,
                base_url=self.ollama_base_url,
                request_timeout=120.0,
                temperature=0.1
            )
            
            # 配置Embedding模型
            embed_model = HuggingFaceEmbedding(
                model_name=self.embed_model_name,
                trust_remote_code=True
            )
            
            # 全局设置
            Settings.llm = llm
            Settings.embed_model = embed_model
            Settings.chunk_size = 512
            Settings.chunk_overlap = 50
            
            self._initialized = True
            return True
            
        except Exception as e:
            print(f"Failed to initialize AI components: {e}")
            return False
    
    def check_ollama_connection(self) -> bool:
        """检查Ollama连接"""
        try:
            import requests
            response = requests.get(f"{self.ollama_base_url}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def get_available_models(self) -> List[str]:
        """获取可用的Ollama模型"""
        try:
            import requests
            response = requests.get(f"{self.ollama_base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                data = response.json()
                return [model['name'] for model in data.get('models', [])]
        except:
            pass
        return []
    
    def index_log_files(self, log_files: List[LogFile], 
                        progress_callback=None) -> bool:
        """索引日志文件"""
        if not LLAMA_INDEX_AVAILABLE:
            return self._index_without_llama(log_files, progress_callback)
            
        try:
            self.documents = []
            self.log_files = {}
            self.entry_mapping = {}
            
            total = len(log_files)
            for i, log_file in enumerate(log_files):
                if progress_callback:
                    progress_callback(i + 1, total, f"索引: {log_file.name}")
                
                self.log_files[log_file.path] = log_file
                
                # 将日志条目转换为文档
                # 按块分组以提高检索效率
                chunk_size = 50  # 每50行作为一个文档块
                for chunk_start in range(0, len(log_file.entries), chunk_size):
                    chunk_end = min(chunk_start + chunk_size, len(log_file.entries))
                    chunk_entries = log_file.entries[chunk_start:chunk_end]
                    
                    if not chunk_entries:
                        continue
                    
                    # 构建文档内容
                    content_lines = []
                    for entry in chunk_entries:
                        content_lines.append(entry.content)
                        entry_id = f"{log_file.path}:{entry.line_number}"
                        self.entry_mapping[entry_id] = entry
                    
                    content = "\n".join(content_lines)
                    
                    # 创建元数据
                    metadata = {
                        'file_path': log_file.path,
                        'file_name': log_file.name,
                        'test_case': log_file.test_case,
                        'log_folder': log_file.log_folder,
                        'start_line': chunk_start + 1,
                        'end_line': chunk_end,
                        'chunk_id': f"{log_file.path}:{chunk_start}"
                    }
                    
                    doc = Document(text=content, metadata=metadata)
                    self.documents.append(doc)
            
            # 创建索引
            if self._initialized and self.documents:
                self.index = VectorStoreIndex.from_documents(
                    self.documents,
                    show_progress=True
                )
                return True
            
            return len(self.documents) > 0
            
        except Exception as e:
            print(f"Error indexing log files: {e}")
            return False
    
    def _index_without_llama(self, log_files: List[LogFile], 
                             progress_callback=None) -> bool:
        """不使用LlamaIndex的简单索引"""
        self.log_files = {}
        self.entry_mapping = {}
        
        total = len(log_files)
        for i, log_file in enumerate(log_files):
            if progress_callback:
                progress_callback(i + 1, total, f"索引: {log_file.name}")
            
            self.log_files[log_file.path] = log_file
            for entry in log_file.entries:
                entry_id = f"{log_file.path}:{entry.line_number}"
                self.entry_mapping[entry_id] = entry
        
        return True
    
    def search(self, query: str, top_k: int = 10) -> List[LogSearchResult]:
        """搜索日志"""
        results = []
        
        # 简单关键词搜索
        query_lower = query.lower()
        keywords = query_lower.split()
        
        scored_entries = []
        for entry_id, entry in self.entry_mapping.items():
            content_lower = entry.content.lower()
            score = sum(1 for kw in keywords if kw in content_lower)
            if score > 0:
                scored_entries.append((entry, score / len(keywords)))
        
        # 按分数排序
        scored_entries.sort(key=lambda x: x[1], reverse=True)
        
        # 获取上下文
        for entry, score in scored_entries[:top_k]:
            log_file = self.log_files.get(entry.file_path)
            context = []
            if log_file:
                parser = LogParser("")
                context = parser.get_context(log_file, entry.line_number, 3)
            
            results.append(LogSearchResult(entry, score, context))
        
        return results
    
    def ask(self, question: str, context_entries: int = 20) -> AISearchResult:
        """向AI提问"""
        if not LLAMA_INDEX_AVAILABLE or not self._initialized or not self.index:
            return self._simple_answer(question)
        
        try:
            # 使用LlamaIndex查询
            query_engine = self.index.as_query_engine(
                similarity_top_k=context_entries,
                response_mode="compact"
            )
            
            # 构建提示
            prompt = f"""你是一个专业的日志分析助手。请根据提供的日志内容回答以下问题。
如果在日志中找到了相关信息，请指出具体的文件和行号。
如果没有找到相关信息，请明确说明。

问题: {question}

请用中文回答，并尽可能提供具体的日志位置信息。"""
            
            response = query_engine.query(prompt)
            
            # 提取源条目
            source_entries = []
            related_files = set()
            
            if hasattr(response, 'source_nodes'):
                for node in response.source_nodes:
                    metadata = node.node.metadata
                    file_path = metadata.get('file_path', '')
                    start_line = metadata.get('start_line', 1)
                    
                    related_files.add(file_path)
                    
                    # 获取相关条目
                    entry_id = f"{file_path}:{start_line}"
                    if entry_id in self.entry_mapping:
                        source_entries.append(self.entry_mapping[entry_id])
            
            return AISearchResult(
                answer=str(response),
                source_entries=source_entries,
                confidence=0.8,
                related_files=list(related_files)
            )
            
        except Exception as e:
            print(f"AI query error: {e}")
            return self._simple_answer(question)
    
    def _simple_answer(self, question: str) -> AISearchResult:
        """简单回答（当AI不可用时）"""
        # 基于关键词搜索
        search_results = self.search(question, top_k=10)
        
        if not search_results:
            return AISearchResult(
                answer="未找到与问题相关的日志内容。请尝试使用不同的关键词。",
                source_entries=[],
                confidence=0.0,
                related_files=[]
            )
        
        # 构建简单回答
        answer_lines = ["基于关键词搜索，找到以下相关日志条目：\n"]
        related_files = set()
        source_entries = []
        
        for result in search_results[:5]:
            entry = result.entry
            answer_lines.append(f"• 文件: {entry.file_path}")
            answer_lines.append(f"  行号: {entry.line_number}")
            answer_lines.append(f"  内容: {entry.content[:200]}...")
            answer_lines.append("")
            
            related_files.add(entry.file_path)
            source_entries.append(entry)
        
        return AISearchResult(
            answer="\n".join(answer_lines),
            source_entries=source_entries,
            confidence=0.5,
            related_files=list(related_files)
        )
    
    def find_by_time(self, target_time: str, tolerance_seconds: int = 60) -> List[LogSearchResult]:
        """按时间查找日志"""
        from datetime import datetime, timedelta
        import re
        
        # 解析时间字符串
        time_patterns = [
            ('%Y-%m-%d %H:%M:%S', r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}'),
            ('%H:%M:%S', r'\d{2}:\d{2}:\d{2}'),
            ('%Y-%m-%d', r'\d{4}-\d{2}-\d{2}'),
        ]
        
        target_dt = None
        for fmt, pattern in time_patterns:
            if re.match(pattern, target_time):
                try:
                    target_dt = datetime.strptime(target_time, fmt)
                    break
                except:
                    continue
        
        if target_dt is None:
            return []
        
        results = []
        tolerance = timedelta(seconds=tolerance_seconds)
        
        for log_file in self.log_files.values():
            for entry in log_file.entries:
                if entry.timestamp is None:
                    continue
                
                # 如果只有时间没有日期，只比较时间部分
                if target_dt.year == 1900:
                    entry_time = entry.timestamp.replace(
                        year=1900, month=1, day=1
                    )
                    target_check = target_dt
                else:
                    entry_time = entry.timestamp
                    target_check = target_dt
                
                diff = abs((entry_time - target_check).total_seconds())
                if diff <= tolerance_seconds:
                    score = 1.0 - (diff / tolerance_seconds)
                    context = []
                    parser = LogParser("")
                    context = parser.get_context(log_file, entry.line_number, 3)
                    results.append(LogSearchResult(entry, score, context))
        
        results.sort(key=lambda x: x.score, reverse=True)
        return results[:20]
    
    def find_errors(self) -> List[LogSearchResult]:
        """查找所有错误日志"""
        results = []
        error_levels = ['ERROR', 'FATAL', 'CRITICAL']
        
        for log_file in self.log_files.values():
            for entry in log_file.entries:
                if entry.level and entry.level.upper() in error_levels:
                    parser = LogParser("")
                    context = parser.get_context(log_file, entry.line_number, 3)
                    results.append(LogSearchResult(entry, 1.0, context))
        
        return results
    
    def save_index(self, path: str) -> bool:
        """保存索引到磁盘"""
        if not LLAMA_INDEX_AVAILABLE or not self.index:
            return False
            
        try:
            self.index.storage_context.persist(persist_dir=path)
            return True
        except Exception as e:
            print(f"Error saving index: {e}")
            return False
    
    def load_index(self, path: str) -> bool:
        """从磁盘加载索引"""
        if not LLAMA_INDEX_AVAILABLE:
            return False
            
        try:
            storage_context = StorageContext.from_defaults(persist_dir=path)
            self.index = load_index_from_storage(storage_context)
            return True
        except Exception as e:
            print(f"Error loading index: {e}")
            return False


class OllamaChat:
    """直接与Ollama对话的类"""
    
    def __init__(self, model_name: str = "qwen3:latest",
                 base_url: str = "http://localhost:11434"):
        self.model_name = model_name
        self.base_url = base_url
        self.history = []
        self.last_system_prompt = None
    
    def chat(self, message: str, context: str = "", system_prompt: str = None) -> str:
        """发送消息并获取回复
        
        Args:
            message: 用户消息
            context: 额外的上下文（将追加到系统提示词）
            system_prompt: 自定义系统提示词（如提供，将覆盖默认提示词）
        """
        try:
            import requests
            
            # 构建系统提示词
            if system_prompt:
                final_system_prompt = system_prompt
            else:
                final_system_prompt = """你是一个专业的测试日志分析助手。你的任务是帮助用户分析和理解测试日志文件。
你可以：
1. 解释日志中的错误和警告
2. 找出日志中的关键信息
3. 对比不同日志文件的差异
4. 提供故障排查建议

请用中文回答，并尽可能提供具体、有用的信息。"""
            
            if context:
                final_system_prompt += f"\n\n当前日志上下文：\n{context}"
            
            # 如果系统提示词变化了，清除历史（因为上下文可能完全不同）
            if self.last_system_prompt != final_system_prompt:
                self.history = []
                self.last_system_prompt = final_system_prompt
            
            payload = {
                "model": self.model_name,
                "messages": [
                    {"role": "system", "content": final_system_prompt},
                    *self.history,
                    {"role": "user", "content": message}
                ],
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "num_ctx": 8192  # 增大上下文窗口
                }
            }
            
            response = requests.post(
                f"{self.base_url}/api/chat",
                json=payload,
                timeout=180  # 增加超时时间
            )
            
            if response.status_code == 200:
                data = response.json()
                assistant_message = data.get('message', {}).get('content', '')
                
                # 清理思考过程标签（某些模型会输出<think>标签）
                import re
                assistant_message = re.sub(r'<think>.*?</think>', '', assistant_message, flags=re.DOTALL)
                assistant_message = assistant_message.strip()
                
                # 保存历史
                self.history.append({"role": "user", "content": message})
                self.history.append({"role": "assistant", "content": assistant_message})
                
                # 限制历史长度
                if len(self.history) > 20:
                    self.history = self.history[-20:]
                
                return assistant_message
            else:
                return f"API错误: {response.status_code}"
                
        except requests.exceptions.ConnectionError:
            return "无法连接到Ollama服务。请确保Ollama正在运行。"
        except requests.exceptions.Timeout:
            return "请求超时。日志内容可能过长，请尝试选择更小的文件或指定行号范围。"
        except Exception as e:
            return f"发生错误: {str(e)}"
    
    def clear_history(self):
        """清除对话历史"""
        self.history = []
        self.last_system_prompt = None
