"""
日志解析器模块 - 负责解析和索引日志文件
"""

import os
import re
import shutil
import zipfile
import tarfile
from datetime import datetime
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from pathlib import Path
import chardet


# 支持的压缩格式
ARCHIVE_EXTENSIONS = {'.zip', '.tar', '.tar.gz', '.tgz', '.tar.bz2', '.tbz2', '.gz'}


def extract_archive(archive_path: Path, extract_to: Path = None) -> bool:
    """解压压缩文件
    
    Args:
        archive_path: 压缩文件路径
        extract_to: 解压目标目录，默认为压缩文件所在目录
    
    Returns:
        是否成功解压
    """
    if extract_to is None:
        extract_to = archive_path.parent
    
    try:
        suffix = ''.join(archive_path.suffixes).lower()
        
        if suffix == '.zip':
            with zipfile.ZipFile(archive_path, 'r') as zf:
                zf.extractall(extract_to)
            return True
        
        elif suffix in ('.tar', '.tar.gz', '.tgz', '.tar.bz2', '.tbz2'):
            mode = 'r:*'  # 自动检测压缩格式
            with tarfile.open(archive_path, mode) as tf:
                tf.extractall(extract_to)
            return True
        
        elif suffix == '.gz' and not str(archive_path).endswith('.tar.gz'):
            import gzip
            output_path = extract_to / archive_path.stem
            with gzip.open(archive_path, 'rb') as f_in:
                with open(output_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
            return True
        
        return False
    except Exception as e:
        print(f"解压失败 {archive_path}: {e}")
        return False


def extract_all_archives(directory: Path, delete_after: bool = True) -> int:
    """递归解压目录下所有压缩文件
    
    Args:
        directory: 目标目录
        delete_after: 解压后是否删除压缩文件
    
    Returns:
        解压的文件数量
    """
    total_extracted = 0
    max_iterations = 10  # 防止无限循环（嵌套压缩包）
    
    for iteration in range(max_iterations):
        found_archives = []
        
        # 查找所有压缩文件
        for root, dirs, files in os.walk(directory):
            for file in files:
                file_path = Path(root) / file
                suffix = ''.join(file_path.suffixes).lower()
                
                # 检查是否是压缩文件
                if any(suffix.endswith(ext) for ext in ARCHIVE_EXTENSIONS):
                    found_archives.append(file_path)
        
        if not found_archives:
            break
        
        # 解压找到的所有压缩文件
        for archive_path in found_archives:
            if extract_archive(archive_path):
                total_extracted += 1
                if delete_after:
                    try:
                        archive_path.unlink()
                    except Exception as e:
                        print(f"删除压缩文件失败 {archive_path}: {e}")
    
    return total_extracted


@dataclass
class LogEntry:
    """单条日志条目"""
    line_number: int
    timestamp: Optional[datetime]
    level: Optional[str]
    content: str
    raw_line: str
    file_path: str
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'line_number': self.line_number,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'level': self.level,
            'content': self.content,
            'raw_line': self.raw_line,
            'file_path': self.file_path
        }


@dataclass
class LogFile:
    """日志文件信息"""
    path: str
    name: str
    size: int
    modified_time: datetime
    test_case: str
    log_folder: str
    entries: List[LogEntry] = field(default_factory=list)
    encoding: str = 'utf-8'
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'path': self.path,
            'name': self.name,
            'size': self.size,
            'modified_time': self.modified_time.isoformat(),
            'test_case': self.test_case,
            'log_folder': self.log_folder,
            'entry_count': len(self.entries),
            'encoding': self.encoding
        }


class LogParser:
    """日志解析器"""
    
    # 常见的日志时间戳格式
    TIMESTAMP_PATTERNS = [
        # 2024-01-15 10:30:45.123
        (r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?)', '%Y-%m-%d %H:%M:%S'),
        # 2024/01/15 10:30:45
        (r'(\d{4}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})', '%Y/%m/%d %H:%M:%S'),
        # 15-Jan-2024 10:30:45
        (r'(\d{2}-\w{3}-\d{4}\s+\d{2}:\d{2}:\d{2})', '%d-%b-%Y %H:%M:%S'),
        # [2024-01-15T10:30:45]
        (r'\[(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})\]', '%Y-%m-%dT%H:%M:%S'),
        # Jan 15 10:30:45
        (r'(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})', '%b %d %H:%M:%S'),
    ]
    
    # 日志级别模式
    LEVEL_PATTERN = re.compile(
        r'\b(DEBUG|INFO|WARN(?:ING)?|ERROR|FATAL|CRITICAL|TRACE|NOTICE)\b',
        re.IGNORECASE
    )
    
    def __init__(self, base_path: str):
        self.base_path = Path(base_path)
        self.log_files: List[LogFile] = []
        
    def detect_encoding(self, file_path: str) -> str:
        """检测文件编码"""
        with open(file_path, 'rb') as f:
            raw_data = f.read(10000)  # 读取前10KB
            result = chardet.detect(raw_data)
            return result['encoding'] or 'utf-8'
    
    def parse_timestamp(self, line: str) -> Optional[datetime]:
        """解析日志行中的时间戳"""
        for pattern, fmt in self.TIMESTAMP_PATTERNS:
            match = re.search(pattern, line)
            if match:
                try:
                    ts_str = match.group(1)
                    # 处理毫秒
                    if '.' in ts_str and '%f' not in fmt:
                        ts_str = ts_str.split('.')[0]
                    return datetime.strptime(ts_str, fmt)
                except ValueError:
                    continue
        return None
    
    def parse_level(self, line: str) -> Optional[str]:
        """解析日志级别"""
        match = self.LEVEL_PATTERN.search(line)
        if match:
            level = match.group(1).upper()
            if level == 'WARNING':
                level = 'WARN'
            return level
        return None
    
    def scan_directory(self) -> List[LogFile]:
        """扫描目录结构，找到所有日志文件"""
        self.log_files = []
        
        if not self.base_path.exists():
            return self.log_files
            
        # 遍历 log 目录结构
        # log / test_case / onekey log / log_folder / *.log
        for test_case_dir in self.base_path.iterdir():
            if not test_case_dir.is_dir():
                continue
                
            test_case_name = test_case_dir.name
            onekey_log_dir = test_case_dir / 'onekey log'
            
            if not onekey_log_dir.exists():
                # 也尝试其他可能的名称
                for alt_name in ['onekey_log', 'onekeylog', 'logs']:
                    alt_dir = test_case_dir / alt_name
                    if alt_dir.exists():
                        onekey_log_dir = alt_dir
                        break
            
            if not onekey_log_dir.exists():
                # 直接在test_case目录下查找log文件
                self._scan_for_logs(test_case_dir, test_case_name, 'root')
                continue
                
            for log_folder in onekey_log_dir.iterdir():
                if log_folder.is_dir():
                    self._scan_for_logs(log_folder, test_case_name, log_folder.name)
                elif log_folder.suffix.lower() in ['.log', '.txt', '.out']:
                    self._add_log_file(log_folder, test_case_name, 'root')
        
        return self.log_files
    
    def _scan_for_logs(self, directory: Path, test_case: str, log_folder: str):
        """在目录中扫描日志文件"""
        log_extensions = {'.log', '.txt', '.out', '.err'}
        
        for item in directory.rglob('*'):
            if item.is_file() and item.suffix.lower() in log_extensions:
                self._add_log_file(item, test_case, log_folder)
    
    def _add_log_file(self, file_path: Path, test_case: str, log_folder: str):
        """添加日志文件到列表"""
        try:
            stat = file_path.stat()
            log_file = LogFile(
                path=str(file_path),
                name=file_path.name,
                size=stat.st_size,
                modified_time=datetime.fromtimestamp(stat.st_mtime),
                test_case=test_case,
                log_folder=log_folder
            )
            self.log_files.append(log_file)
        except Exception as e:
            print(f"Error adding log file {file_path}: {e}")
    
    def parse_log_file(self, log_file: LogFile, max_lines: int = None) -> LogFile:
        """解析单个日志文件的内容"""
        try:
            log_file.encoding = self.detect_encoding(log_file.path)
            
            with open(log_file.path, 'r', encoding=log_file.encoding, errors='replace') as f:
                for line_num, line in enumerate(f, 1):
                    if max_lines and line_num > max_lines:
                        break
                        
                    line = line.rstrip('\n\r')
                    entry = LogEntry(
                        line_number=line_num,
                        timestamp=self.parse_timestamp(line),
                        level=self.parse_level(line),
                        content=line,
                        raw_line=line,
                        file_path=log_file.path
                    )
                    log_file.entries.append(entry)
                    
        except Exception as e:
            print(f"Error parsing log file {log_file.path}: {e}")
            
        return log_file
    
    def search_by_time_range(self, log_file: LogFile, 
                             start_time: datetime = None, 
                             end_time: datetime = None) -> List[LogEntry]:
        """按时间范围搜索日志条目"""
        results = []
        for entry in log_file.entries:
            if entry.timestamp is None:
                continue
            if start_time and entry.timestamp < start_time:
                continue
            if end_time and entry.timestamp > end_time:
                continue
            results.append(entry)
        return results
    
    def search_by_keyword(self, log_file: LogFile, 
                          keyword: str, 
                          case_sensitive: bool = False) -> List[LogEntry]:
        """按关键词搜索日志条目"""
        results = []
        pattern = keyword if case_sensitive else keyword.lower()
        
        for entry in log_file.entries:
            content = entry.content if case_sensitive else entry.content.lower()
            if pattern in content:
                results.append(entry)
        return results
    
    def search_by_level(self, log_file: LogFile, levels: List[str]) -> List[LogEntry]:
        """按日志级别搜索"""
        levels_upper = [l.upper() for l in levels]
        return [e for e in log_file.entries if e.level and e.level.upper() in levels_upper]
    
    def get_context(self, log_file: LogFile, line_number: int, 
                    context_lines: int = 5) -> List[LogEntry]:
        """获取某行的上下文"""
        start = max(0, line_number - context_lines - 1)
        end = min(len(log_file.entries), line_number + context_lines)
        return log_file.entries[start:end]


class LogSearchResult:
    """日志搜索结果"""
    def __init__(self, entry: LogEntry, score: float = 1.0, 
                 context: List[LogEntry] = None):
        self.entry = entry
        self.score = score
        self.context = context or []
        
    def to_dict(self) -> Dict[str, Any]:
        return {
            'entry': self.entry.to_dict(),
            'score': self.score,
            'context': [e.to_dict() for e in self.context]
        }
