import os


def merge_md_files(folder_path, output_file='代码随想录.md'):
    # 检查文件夹是否存在
    if not os.path.exists(folder_path):
        print(f"文件夹 '{folder_path}' 不存在。")
        return

    # 检查文件夹路径是否合法
    if not os.path.isdir(folder_path):
        print(f"'{folder_path}' 不是一个有效的文件夹路径。")
        return

    # 获取文件夹内所有 .md 文件的路径
    md_files = [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith('.md')]

    # 如果没有 .md 文件，给出提示并返回
    if not md_files:
        print(f"文件夹 '{folder_path}' 中没有 .md 文件。")
        return

    # 合并所有 .md 文件的内容
    with open(output_file, 'w', encoding='utf-8') as merged_file:
        for md_file in md_files:
            with open(md_file, 'r', encoding='utf-8') as f:
                merged_file.write(f.read() + '\n')

    print(f"{len(md_files)} 个 .md 文件已成功合并到 '{output_file}' 中。")


# 用法示例：
merge_md_files('tmp')
