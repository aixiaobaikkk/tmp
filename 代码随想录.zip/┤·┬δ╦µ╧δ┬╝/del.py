import os

def remove_content_after_title(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        for i, line in enumerate(lines):
            if "## 其他语言版本" in line:
                with open(file_path, 'w', encoding='utf-8') as file:
                    file.writelines(lines[:i])
                break

    except Exception as e:
        print(f"Error processing file: {file_path}")
        print(e)

def remove_content_from_files_in_directory(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".md"):
                file_path = os.path.join(root, file)
                remove_content_after_title(file_path)

if __name__ == "__main__":
    directory_path = "tmp"  # 替换成你的文件夹路径
    remove_content_from_files_in_directory(directory_path)
