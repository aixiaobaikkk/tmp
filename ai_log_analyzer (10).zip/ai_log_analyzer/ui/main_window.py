"""
主窗口UI模块
"""

import sys
import os
import re
from datetime import datetime
from typing import Optional, List
from pathlib import Path

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QTreeWidget, QTreeWidgetItem, QTextEdit, QPlainTextEdit, QLineEdit, QPushButton,
    QTabWidget, QLabel, QProgressBar, QStatusBar, QToolBar, QMenu,
    QMenuBar, QFileDialog, QMessageBox, QDialog, QDialogButtonBox,
    QComboBox, QCheckBox, QSpinBox, QGroupBox, QFormLayout,
    QListWidget, QListWidgetItem, QFrame, QScrollArea, QApplication
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QSize
from PyQt6.QtGui import (
    QAction, QIcon, QFont, QColor, QPalette, QTextCharFormat,
    QSyntaxHighlighter, QTextDocument, QKeySequence, QShortcut
)

# 导入核心模块
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core import (
    LogParser, LogFile, LogEntry, LogSearchResult,
    LogAIIndexer, AISearchResult, OllamaChat,
    LogComparator, DiffResult, DiffType
)


class LogHighlighter(QSyntaxHighlighter):
    """日志语法高亮器"""
    
    def __init__(self, parent: QTextDocument):
        super().__init__(parent)
        self.highlighting_rules = []
        
        # 错误级别 - 红色
        error_format = QTextCharFormat()
        error_format.setForeground(QColor("#FF5555"))
        error_format.setFontWeight(QFont.Weight.Bold)
        self.highlighting_rules.append((
            r'\b(ERROR|FATAL|CRITICAL)\b',
            error_format
        ))
        
        # 警告级别 - 橙色
        warn_format = QTextCharFormat()
        warn_format.setForeground(QColor("#FFB86C"))
        self.highlighting_rules.append((
            r'\b(WARN|WARNING)\b',
            warn_format
        ))
        
        # 信息级别 - 绿色
        info_format = QTextCharFormat()
        info_format.setForeground(QColor("#50FA7B"))
        self.highlighting_rules.append((
            r'\b(INFO)\b',
            info_format
        ))
        
        # 调试级别 - 青色
        debug_format = QTextCharFormat()
        debug_format.setForeground(QColor("#8BE9FD"))
        self.highlighting_rules.append((
            r'\b(DEBUG|TRACE)\b',
            debug_format
        ))
        
        # 时间戳 - 紫色
        timestamp_format = QTextCharFormat()
        timestamp_format.setForeground(QColor("#BD93F9"))
        self.highlighting_rules.append((
            r'\d{4}[-/]\d{2}[-/]\d{2}[\sT]\d{2}:\d{2}:\d{2}(?:\.\d+)?',
            timestamp_format
        ))
        
        # 数字 - 粉色
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#FF79C6"))
        self.highlighting_rules.append((
            r'\b\d+(?:\.\d+)?\b',
            number_format
        ))
        
        # 引号内容 - 黄色
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#F1FA8C"))
        self.highlighting_rules.append((
            r'"[^"]*"',
            string_format
        ))
        self.highlighting_rules.append((
            r"'[^']*'",
            string_format
        ))
        
        import re
        self.compiled_rules = [
            (re.compile(pattern), fmt) 
            for pattern, fmt in self.highlighting_rules
        ]
    
    def highlightBlock(self, text: str):
        for pattern, fmt in self.compiled_rules:
            for match in pattern.finditer(text):
                self.setFormat(match.start(), match.end() - match.start(), fmt)


class WorkerThread(QThread):
    """工作线程"""
    progress = pyqtSignal(int, int, str)
    finished = pyqtSignal(object)
    error = pyqtSignal(str)
    
    def __init__(self, func, *args, **kwargs):
        super().__init__()
        self.func = func
        self.args = args
        self.kwargs = kwargs
    
    def run(self):
        try:
            result = self.func(*self.args, **self.kwargs)
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


class FileTreeWidget(QTreeWidget):
    """文件树组件"""
    
    file_selected = pyqtSignal(str)
    files_selected_for_compare = pyqtSignal(list)
    file_send_to_ai = pyqtSignal(str)  # 发送到AI分析
    
    def __init__(self):
        super().__init__()
        self.setHeaderLabels(['名称', '大小', '修改时间'])
        self.setColumnWidth(0, 250)
        self.setColumnWidth(1, 80)
        self.setSelectionMode(QTreeWidget.SelectionMode.ExtendedSelection)
        self.itemDoubleClicked.connect(self._on_item_double_clicked)
        
        # 右键菜单
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._show_context_menu)
        
        self.log_files = {}
    
    def load_log_files(self, log_files: List[LogFile]):
        """加载日志文件列表"""
        self.clear()
        self.log_files = {}
        
        # 按测试用例分组
        test_cases = {}
        for log_file in log_files:
            if log_file.test_case not in test_cases:
                test_cases[log_file.test_case] = {}
            if log_file.log_folder not in test_cases[log_file.test_case]:
                test_cases[log_file.test_case][log_file.log_folder] = []
            test_cases[log_file.test_case][log_file.log_folder].append(log_file)
            self.log_files[log_file.path] = log_file
        
        # 构建树
        for test_case, folders in test_cases.items():
            test_item = QTreeWidgetItem([test_case, '', ''])
            test_item.setIcon(0, self.style().standardIcon(
                self.style().StandardPixmap.SP_DirIcon
            ))
            
            for folder, files in folders.items():
                folder_item = QTreeWidgetItem([folder, '', ''])
                folder_item.setIcon(0, self.style().standardIcon(
                    self.style().StandardPixmap.SP_DirOpenIcon
                ))
                
                for log_file in files:
                    size_str = self._format_size(log_file.size)
                    time_str = log_file.modified_time.strftime('%Y-%m-%d %H:%M')
                    file_item = QTreeWidgetItem([log_file.name, size_str, time_str])
                    file_item.setData(0, Qt.ItemDataRole.UserRole, log_file.path)
                    file_item.setIcon(0, self.style().standardIcon(
                        self.style().StandardPixmap.SP_FileIcon
                    ))
                    folder_item.addChild(file_item)
                
                test_item.addChild(folder_item)
            
            self.addTopLevelItem(test_item)
        
        self.expandAll()
    
    def _format_size(self, size: int) -> str:
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f}{unit}"
            size /= 1024
        return f"{size:.1f}TB"
    
    def _on_item_double_clicked(self, item: QTreeWidgetItem, column: int):
        """双击项目"""
        path = item.data(0, Qt.ItemDataRole.UserRole)
        if path:
            self.file_selected.emit(path)
    
    def _show_context_menu(self, position):
        """显示右键菜单"""
        menu = QMenu()
        
        # 获取选中的文件
        items = self.selectedItems()
        paths = [item.data(0, Qt.ItemDataRole.UserRole) 
                for item in items if item.data(0, Qt.ItemDataRole.UserRole)]
        
        has_files = len(paths) > 0
        
        open_action = menu.addAction("📂 打开")
        open_action.setEnabled(has_files)
        
        ai_action = menu.addAction("🤖 发送到AI分析")
        ai_action.setEnabled(has_files)
        
        menu.addSeparator()
        
        # 根据选中数量显示不同选项
        if len(paths) >= 2:
            sync_action = menu.addAction(f"📊 多日志同步查看 ({len(paths)}个)")
        elif len(paths) == 1:
            sync_action = menu.addAction("📊 打开同步查看器")
        else:
            sync_action = menu.addAction("📊 多日志同步查看")
            sync_action.setEnabled(False)
        
        menu.addSeparator()
        refresh_action = menu.addAction("🔄 刷新")
        
        action = menu.exec(self.mapToGlobal(position))
        
        if action == open_action and has_files:
            path = paths[0]
            self.file_selected.emit(path)
        
        elif action == ai_action and has_files:
            path = paths[0]
            self.file_send_to_ai.emit(path)
        
        elif sync_action and action == sync_action and paths:
            self.files_selected_for_compare.emit(paths[:4])  # 最多4个
    
    def get_selected_log_file(self) -> Optional[LogFile]:
        """获取选中的日志文件"""
        items = self.selectedItems()
        if items:
            path = items[0].data(0, Qt.ItemDataRole.UserRole)
            if path:
                return self.log_files.get(path)
        return None


class LogViewerWidget(QWidget):
    """日志查看器组件 - 带有Notepad++风格的实用功能"""
    
    def __init__(self):
        super().__init__()
        self.current_file: Optional[LogFile] = None
        self.bookmarks = set()  # 书签行号集合
        self.search_results = []  # 搜索结果列表
        self._search_match_lengths = []  # 每个搜索结果的匹配长度
        self.current_search_index = -1
        self.highlight_words = {}  # {关键词: 颜色}
        self.original_lines = []  # 原始行内容
        self.filtered_lines = []  # 过滤后的行
        self.is_filtered = False
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)
        
        # 工具栏1 - 文件信息和基本操作
        toolbar1 = QHBoxLayout()
        
        self.file_label = QLabel("未打开文件")
        self.file_label.setStyleSheet("font-weight: bold;")
        toolbar1.addWidget(self.file_label)
        
        # 复制路径按钮
        self.copy_path_btn = QPushButton("📋")
        self.copy_path_btn.setMaximumWidth(30)
        self.copy_path_btn.setToolTip("复制文件路径")
        self.copy_path_btn.clicked.connect(self.copy_file_path)
        toolbar1.addWidget(self.copy_path_btn)
        
        toolbar1.addStretch()
        
        # 过滤器
        toolbar1.addWidget(QLabel("过滤:"))
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["全部", "ERROR", "WARN", "INFO", "DEBUG", "自定义..."])
        self.filter_combo.currentTextChanged.connect(self.on_filter_changed)
        self.filter_combo.setMaximumWidth(100)
        toolbar1.addWidget(self.filter_combo)
        
        # 时间过滤
        self.time_filter_btn = QPushButton("⏱ 时间过滤")
        self.time_filter_btn.clicked.connect(self.show_time_filter_dialog)
        toolbar1.addWidget(self.time_filter_btn)
        
        # 清除过滤
        self.clear_filter_btn = QPushButton("✖ 清除过滤")
        self.clear_filter_btn.clicked.connect(self.clear_filter)
        self.clear_filter_btn.setEnabled(False)
        toolbar1.addWidget(self.clear_filter_btn)
        
        layout.addLayout(toolbar1)
        
        # 工具栏2 - 搜索和导航
        toolbar2 = QHBoxLayout()
        
        toolbar2.addWidget(QLabel("🔍"))
        
        # 搜索框
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("搜索 (Ctrl+F)")
        self.search_input.setMaximumWidth(200)
        self.search_input.returnPressed.connect(self.find_next)
        self.search_input.textChanged.connect(self._on_search_text_changed)
        toolbar2.addWidget(self.search_input)
        
        # 模糊搜索选项
        self.fuzzy_checkbox = QCheckBox("模糊")
        self.fuzzy_checkbox.setToolTip("启用模糊匹配 (允许字符间有其他字符)")
        self.fuzzy_checkbox.stateChanged.connect(self._on_search_option_changed)
        toolbar2.addWidget(self.fuzzy_checkbox)
        
        # 大小写敏感
        self.case_checkbox = QCheckBox("区分大小写")
        self.case_checkbox.stateChanged.connect(self._on_search_option_changed)
        toolbar2.addWidget(self.case_checkbox)
        
        self.find_prev_btn = QPushButton("▲上一个")
        self.find_prev_btn.setToolTip("查找上一个 (Shift+F3)")
        self.find_prev_btn.clicked.connect(self.find_prev)
        toolbar2.addWidget(self.find_prev_btn)
        
        self.find_next_btn = QPushButton("▼下一个")
        self.find_next_btn.setToolTip("查找下一个 (F3)")
        self.find_next_btn.clicked.connect(self.find_next)
        toolbar2.addWidget(self.find_next_btn)
        
        self.search_count_label = QLabel("")
        self.search_count_label.setStyleSheet("color: #89b4fa; font-weight: bold;")
        toolbar2.addWidget(self.search_count_label)
        
        toolbar2.addWidget(QLabel("|"))
        
        # 高亮关键词
        self.highlight_input = QLineEdit()
        self.highlight_input.setPlaceholderText("高亮关键词")
        self.highlight_input.setMaximumWidth(120)
        toolbar2.addWidget(self.highlight_input)
        
        self.highlight_color = QComboBox()
        self.highlight_color.addItems(["🟡 黄色", "🟢 绿色", "🔵 蓝色", "🟣 紫色", "🟠 橙色"])
        self.highlight_color.setMaximumWidth(80)
        toolbar2.addWidget(self.highlight_color)
        
        self.add_highlight_btn = QPushButton("添加")
        self.add_highlight_btn.clicked.connect(self.add_highlight)
        toolbar2.addWidget(self.add_highlight_btn)
        
        self.clear_highlight_btn = QPushButton("清除高亮")
        self.clear_highlight_btn.clicked.connect(self.clear_highlights)
        toolbar2.addWidget(self.clear_highlight_btn)
        
        toolbar2.addStretch()
        
        # 跳转到行
        self.goto_input = QLineEdit()
        self.goto_input.setPlaceholderText("行号")
        self.goto_input.setMaximumWidth(60)
        self.goto_input.returnPressed.connect(self.goto_line)
        toolbar2.addWidget(self.goto_input)
        
        self.goto_btn = QPushButton("跳转")
        self.goto_btn.clicked.connect(self.goto_line)
        toolbar2.addWidget(self.goto_btn)
        
        layout.addLayout(toolbar2)
        
        # 工具栏3 - 书签和统计
        toolbar3 = QHBoxLayout()
        
        self.bookmark_btn = QPushButton("🔖 添加书签")
        self.bookmark_btn.setToolTip("在当前行添加/移除书签 (Ctrl+B)")
        self.bookmark_btn.clicked.connect(self.toggle_bookmark)
        toolbar3.addWidget(self.bookmark_btn)
        
        self.prev_bookmark_btn = QPushButton("◀ 上一书签")
        self.prev_bookmark_btn.clicked.connect(self.goto_prev_bookmark)
        toolbar3.addWidget(self.prev_bookmark_btn)
        
        self.next_bookmark_btn = QPushButton("下一书签 ▶")
        self.next_bookmark_btn.clicked.connect(self.goto_next_bookmark)
        toolbar3.addWidget(self.next_bookmark_btn)
        
        self.clear_bookmarks_btn = QPushButton("清除所有书签")
        self.clear_bookmarks_btn.clicked.connect(self.clear_all_bookmarks)
        toolbar3.addWidget(self.clear_bookmarks_btn)
        
        toolbar3.addWidget(QLabel("|"))
        
        self.stats_btn = QPushButton("📊 统计")
        self.stats_btn.clicked.connect(self.show_statistics)
        toolbar3.addWidget(self.stats_btn)
        
        self.count_keyword_btn = QPushButton("🔢 统计关键词")
        self.count_keyword_btn.clicked.connect(self.count_keyword)
        toolbar3.addWidget(self.count_keyword_btn)
        
        toolbar3.addStretch()
        
        self.bookmark_count_label = QLabel("书签: 0")
        self.bookmark_count_label.setStyleSheet("color: #fab387;")
        toolbar3.addWidget(self.bookmark_count_label)
        
        layout.addLayout(toolbar3)
        
        # 日志内容
        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setFont(QFont("Consolas", 10))
        self.text_edit.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        self.text_edit.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.text_edit.customContextMenuRequested.connect(self.show_context_menu)
        
        # 设置暗色主题
        self.text_edit.setStyleSheet("""
            QTextEdit {
                background-color: #282a36;
                color: #f8f8f2;
                border: 1px solid #44475a;
                selection-background-color: #44475a;
            }
        """)
        
        # 添加语法高亮
        self.highlighter = LogHighlighter(self.text_edit.document())
        
        layout.addWidget(self.text_edit)
        
        # 状态栏
        status_layout = QHBoxLayout()
        self.line_info_label = QLabel("行: - | 列: -")
        status_layout.addWidget(self.line_info_label)
        
        status_layout.addStretch()
        
        self.status_label = QLabel("就绪")
        status_layout.addWidget(self.status_label)
        
        layout.addLayout(status_layout)
        
        # 连接光标变化信号
        self.text_edit.cursorPositionChanged.connect(self.update_cursor_info)
        
        # 设置快捷键
        self.setup_shortcuts()
    
    def setup_shortcuts(self):
        """设置快捷键"""
        # Ctrl+F - 搜索（使用选中文本）
        QShortcut(QKeySequence("Ctrl+F"), self, self.focus_search_with_selection)
        # F3 - 查找下一个
        QShortcut(QKeySequence("F3"), self, self.find_next)
        # Shift+F3 - 查找上一个
        QShortcut(QKeySequence("Shift+F3"), self, self.find_prev)
        # Ctrl+B - 切换书签
        QShortcut(QKeySequence("Ctrl+B"), self, self.toggle_bookmark)
        # Ctrl+G - 跳转到行
        QShortcut(QKeySequence("Ctrl+G"), self, lambda: self.goto_input.setFocus())
        # Escape - 清除搜索焦点
        QShortcut(QKeySequence("Escape"), self, self.clear_search_focus)
    
    def focus_search_with_selection(self):
        """聚焦搜索框并使用选中的文本"""
        selected = self.text_edit.textCursor().selectedText()
        if selected:
            # 暂时断开信号，避免textChanged触发清除
            self.search_input.blockSignals(True)
            self.search_input.setText(selected)
            self.search_input.blockSignals(False)
            # 直接执行搜索
            self.find_next()
        self.search_input.setFocus()
        self.search_input.selectAll()
    
    def clear_search_focus(self):
        """清除搜索焦点并清除搜索高亮"""
        self._clear_search_highlight()
        self.search_count_label.setText("")
        self.text_edit.setFocus()
    
    def _on_search_text_changed(self, text):
        """搜索文本变化时清除之前的搜索结果"""
        # 清除搜索高亮（保留关键词高亮）
        self.search_results = []
        self._search_match_lengths = []
        self.current_search_index = -1
        self.search_count_label.setText("")
        self._update_search_highlights()
    
    def _on_search_option_changed(self):
        """搜索选项变化时清除之前的搜索结果并重新搜索"""
        # 清除搜索高亮
        self.search_results = []
        self._search_match_lengths = []
        self.current_search_index = -1
        self.search_count_label.setText("")
        # 如果有搜索文本，自动重新搜索
        if self.search_input.text().strip():
            QTimer.singleShot(50, self.find_next)
        else:
            self._update_search_highlights()
    
    def show_context_menu(self, position):
        """显示右键菜单"""
        menu = QMenu(self)
        
        # 复制
        copy_action = menu.addAction("📋 复制")
        copy_action.triggered.connect(self.text_edit.copy)
        
        # 复制当前行
        copy_line_action = menu.addAction("📋 复制当前行")
        copy_line_action.triggered.connect(self.copy_current_line)
        
        menu.addSeparator()
        
        # 书签
        bookmark_action = menu.addAction("🔖 切换书签")
        bookmark_action.triggered.connect(self.toggle_bookmark)
        
        menu.addSeparator()
        
        # 搜索选中内容
        selected = self.text_edit.textCursor().selectedText()
        if selected:
            search_selected_action = menu.addAction(f"🔍 搜索: {selected[:20]}...")
            search_selected_action.triggered.connect(lambda: self.search_selected(selected))
            
            highlight_selected_action = menu.addAction(f"✨ 高亮: {selected[:20]}...")
            highlight_selected_action.triggered.connect(lambda: self.highlight_selected(selected))
        
        menu.addSeparator()
        
        # 统计
        if selected:
            count_action = menu.addAction(f"🔢 统计出现次数")
            count_action.triggered.connect(lambda: self.count_selected(selected))
        
        menu.exec(self.text_edit.mapToGlobal(position))
    
    def load_file(self, log_file: LogFile):
        """加载日志文件"""
        self.current_file = log_file
        self.file_label.setText(f"📄 {log_file.name} ({log_file.test_case})")
        
        # 保存原始行
        self.original_lines = []
        for entry in log_file.entries:
            self.original_lines.append((entry.line_number, entry.content, entry.level, entry.timestamp))
        
        # 显示内容
        self.show_lines(self.original_lines)
        self.is_filtered = False
        self.clear_filter_btn.setEnabled(False)
        
        # 清空书签和搜索
        self.bookmarks.clear()
        self.search_results.clear()
        self.update_bookmark_count()
    
    def show_lines(self, lines):
        """显示行内容"""
        display_lines = []
        for line_num, content, level, ts in lines:
            display_lines.append(f"{line_num:6d} | {content}")
        
        self.text_edit.setPlainText('\n'.join(display_lines))
        self.status_label.setText(f"共 {len(lines)} 行")
    
    def on_filter_changed(self, filter_text):
        """过滤器变化"""
        if filter_text == "全部":
            self.clear_filter()
        elif filter_text == "自定义...":
            self.show_custom_filter_dialog()
        else:
            self.filter_by_level(filter_text)
    
    def filter_by_level(self, level: str):
        """按日志级别过滤"""
        self.filtered_lines = [
            line for line in self.original_lines
            if line[2] and line[2].upper() == level.upper()
        ]
        self.show_lines(self.filtered_lines)
        self.is_filtered = True
        self.clear_filter_btn.setEnabled(True)
        self.status_label.setText(f"已过滤: 显示 {len(self.filtered_lines)}/{len(self.original_lines)} 行 ({level})")
    
    def show_time_filter_dialog(self):
        """显示时间过滤对话框"""
        dialog = QDialog(self)
        dialog.setWindowTitle("时间过滤")
        dialog.setMinimumWidth(300)
        
        layout = QVBoxLayout(dialog)
        
        layout.addWidget(QLabel("输入时间范围 (格式: HH:MM:SS 或 HH:MM)"))
        
        from_layout = QHBoxLayout()
        from_layout.addWidget(QLabel("从:"))
        from_input = QLineEdit()
        from_input.setPlaceholderText("例如: 10:30:00")
        from_layout.addWidget(from_input)
        layout.addLayout(from_layout)
        
        to_layout = QHBoxLayout()
        to_layout.addWidget(QLabel("到:"))
        to_input = QLineEdit()
        to_input.setPlaceholderText("例如: 11:00:00")
        to_layout.addWidget(to_input)
        layout.addLayout(to_layout)
        
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            from_time = from_input.text().strip()
            to_time = to_input.text().strip()
            self.filter_by_time(from_time, to_time)
    
    def filter_by_time(self, from_time: str, to_time: str):
        """按时间范围过滤"""
        try:
            # 解析时间
            def parse_time(t):
                if len(t.split(':')) == 2:
                    return datetime.strptime(t, '%H:%M').time()
                return datetime.strptime(t, '%H:%M:%S').time()
            
            start = parse_time(from_time) if from_time else None
            end = parse_time(to_time) if to_time else None
            
            self.filtered_lines = []
            for line in self.original_lines:
                ts = line[3]
                if ts:
                    t = ts.time()
                    if start and t < start:
                        continue
                    if end and t > end:
                        continue
                    self.filtered_lines.append(line)
            
            self.show_lines(self.filtered_lines)
            self.is_filtered = True
            self.clear_filter_btn.setEnabled(True)
            self.status_label.setText(f"时间过滤: 显示 {len(self.filtered_lines)}/{len(self.original_lines)} 行")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"时间格式错误: {e}")
    
    def show_custom_filter_dialog(self):
        """显示自定义过滤对话框"""
        from PyQt6.QtWidgets import QInputDialog
        keyword, ok = QInputDialog.getText(self, "自定义过滤", "输入过滤关键词 (支持正则表达式):")
        if ok and keyword:
            self.filter_by_keyword(keyword)
    
    def filter_by_keyword(self, keyword: str):
        """按关键词过滤"""
        import re
        
        # 检查是否是正则表达式
        if keyword.startswith('/') and keyword.endswith('/'):
            pattern = re.compile(keyword[1:-1], re.IGNORECASE)
            self.filtered_lines = [
                line for line in self.original_lines
                if pattern.search(line[1])
            ]
        else:
            keyword_lower = keyword.lower()
            self.filtered_lines = [
                line for line in self.original_lines
                if keyword_lower in line[1].lower()
            ]
        
        self.show_lines(self.filtered_lines)
        self.is_filtered = True
        self.clear_filter_btn.setEnabled(True)
        self.filter_combo.setCurrentText("全部")  # 重置下拉框
        self.status_label.setText(f"关键词过滤: 显示 {len(self.filtered_lines)}/{len(self.original_lines)} 行")
    
    def clear_filter(self):
        """清除过滤"""
        self.show_lines(self.original_lines)
        self.is_filtered = False
        self.clear_filter_btn.setEnabled(False)
        self.filter_combo.setCurrentText("全部")
        self.status_label.setText(f"共 {len(self.original_lines)} 行")
    
    def _build_fuzzy_pattern(self, keyword: str) -> str:
        """构建模糊搜索的正则表达式模式"""
        # 在每个字符之间插入 .*? 允许有其他字符
        escaped = [re.escape(c) for c in keyword]
        return '.*?'.join(escaped)
    
    def _update_search_highlights(self):
        """使用ExtraSelections高效更新搜索高亮"""
        selections = []
        
        if self.search_results and self._search_match_lengths:
            # 限制高亮数量，防止大文件卡顿
            max_highlights = 2000
            results_to_highlight = self.search_results[:max_highlights]
            
            # 普通匹配项格式（淡黄色）
            normal_fmt = QTextCharFormat()
            normal_fmt.setBackground(QColor("#FFE082"))
            normal_fmt.setForeground(QColor("#1e1e2e"))
            
            # 当前匹配项格式（橙色）
            current_fmt = QTextCharFormat()
            current_fmt.setBackground(QColor("#FF6B35"))
            current_fmt.setForeground(QColor("#FFFFFF"))
            
            for i, pos in enumerate(results_to_highlight):
                match_len = self._search_match_lengths[i] if i < len(self._search_match_lengths) else 1
                
                selection = QTextEdit.ExtraSelection()
                cursor = self.text_edit.textCursor()
                cursor.setPosition(pos)
                cursor.movePosition(cursor.MoveOperation.Right, cursor.MoveMode.KeepAnchor, match_len)
                selection.cursor = cursor
                
                # 当前匹配项使用不同颜色
                if i == self.current_search_index:
                    selection.format = current_fmt
                else:
                    selection.format = normal_fmt
                
                selections.append(selection)
            
            # 如果结果超过限制，显示提示
            if len(self.search_results) > max_highlights:
                self.search_count_label.setText(f"共 {len(self.search_results)} 个 (显示前{max_highlights}个高亮)")
        
        # 合并关键词高亮
        selections.extend(self._get_keyword_highlight_selections())
        
        # 一次性设置所有高亮
        self.text_edit.setExtraSelections(selections)
    
    def _get_keyword_highlight_selections(self) -> list:
        """获取关键词高亮的ExtraSelections"""
        selections = []
        
        if not self.highlight_words:
            return selections
        
        text = self.text_edit.toPlainText()
        max_highlights_per_keyword = 500  # 每个关键词最多高亮500个
        
        for keyword, color in self.highlight_words.items():
            fmt = QTextCharFormat()
            fmt.setBackground(QColor(color))
            fmt.setForeground(QColor("#1e1e2e"))
            
            # 查找所有匹配
            start = 0
            count = 0
            keyword_lower = keyword.lower()
            text_lower = text.lower()
            
            while count < max_highlights_per_keyword:
                pos = text_lower.find(keyword_lower, start)
                if pos == -1:
                    break
                
                selection = QTextEdit.ExtraSelection()
                cursor = self.text_edit.textCursor()
                cursor.setPosition(pos)
                cursor.movePosition(cursor.MoveOperation.Right, cursor.MoveMode.KeepAnchor, len(keyword))
                selection.cursor = cursor
                selection.format = fmt
                selections.append(selection)
                
                start = pos + 1
                count += 1
        
        return selections
    
    def find_next(self):
        """查找下一个"""
        keyword = self.search_input.text().strip()
        if not keyword:
            self._clear_search_highlight()
            return
        
        # 检查搜索选项是否改变
        current_options = (
            keyword,
            self.fuzzy_checkbox.isChecked(),
            self.case_checkbox.isChecked()
        )
        
        # 首次搜索或选项改变，构建结果列表
        need_rebuild = not self.search_results or current_options != getattr(self, '_last_search_options', None)
        
        if need_rebuild:
            self._last_search_options = current_options
            self.search_results = []
            self._search_match_lengths = []  # 记录每个匹配的长度
            text = self.text_edit.toPlainText()
            
            # 确定大小写敏感性
            flags = 0 if self.case_checkbox.isChecked() else re.IGNORECASE
            
            if self.fuzzy_checkbox.isChecked():
                # 模糊搜索
                pattern_str = self._build_fuzzy_pattern(keyword)
                try:
                    pattern = re.compile(pattern_str, flags)
                    for match in pattern.finditer(text):
                        self.search_results.append(match.start())
                        self._search_match_lengths.append(match.end() - match.start())
                except re.error:
                    self.status_label.setText("搜索模式错误")
                    return
            elif keyword.startswith('/') and keyword.endswith('/') and len(keyword) > 2:
                # 正则表达式搜索
                try:
                    pattern = re.compile(keyword[1:-1], flags)
                    for match in pattern.finditer(text):
                        self.search_results.append(match.start())
                        self._search_match_lengths.append(match.end() - match.start())
                except re.error:
                    self.status_label.setText("正则表达式错误")
                    return
            else:
                # 普通搜索 - 优化：直接使用字符串查找
                search_text = text if self.case_checkbox.isChecked() else text.lower()
                search_keyword = keyword if self.case_checkbox.isChecked() else keyword.lower()
                keyword_len = len(keyword)
                start = 0
                while True:
                    pos = search_text.find(search_keyword, start)
                    if pos == -1:
                        break
                    self.search_results.append(pos)
                    self._search_match_lengths.append(keyword_len)
                    start = pos + 1
            
            self.current_search_index = -1
            self.search_count_label.setText(f"共 {len(self.search_results)} 个")
        
        if not self.search_results:
            self.status_label.setText("未找到匹配项")
            self.search_count_label.setText("0 个")
            self._clear_search_highlight()
            return
        
        # 移动到下一个
        self.current_search_index = (self.current_search_index + 1) % len(self.search_results)
        
        # 更新高亮（使用ExtraSelections，高效）
        self._update_search_highlights()
        
        # 跳转到当前结果
        self._goto_search_result()
    
    def _clear_search_highlight(self):
        """清除搜索高亮"""
        self.search_results = []
        self._search_match_lengths = []
        self.current_search_index = -1
        # 使用ExtraSelections，只需要更新即可（保留关键词高亮）
        self._update_search_highlights()
    
    def find_prev(self):
        """查找上一个"""
        if not self.search_results:
            self.find_next()
            return
        
        self.current_search_index = (self.current_search_index - 1) % len(self.search_results)
        
        # 更新高亮
        self._update_search_highlights()
        
        # 跳转到当前结果
        self._goto_search_result()
    
    def _goto_search_result(self):
        """跳转到搜索结果"""
        if not self.search_results or self.current_search_index < 0:
            return
        
        pos = self.search_results[self.current_search_index]
        
        # 获取匹配长度
        match_len = len(self.search_input.text().strip('/'))
        if hasattr(self, '_search_match_lengths') and self.current_search_index < len(self._search_match_lengths):
            match_len = self._search_match_lengths[self.current_search_index]
        
        # 移动光标并滚动到可见区域
        cursor = self.text_edit.textCursor()
        cursor.setPosition(pos)
        cursor.movePosition(cursor.MoveOperation.Right, cursor.MoveMode.KeepAnchor, match_len)
        self.text_edit.setTextCursor(cursor)
        self.text_edit.ensureCursorVisible()
        self.status_label.setText(f"结果 {self.current_search_index + 1}/{len(self.search_results)}")
    
    def add_highlight(self):
        """添加高亮关键词"""
        keyword = self.highlight_input.text().strip()
        if not keyword:
            return
        
        colors = {
            "🟡 黄色": "#F1FA8C",
            "🟢 绿色": "#50FA7B",
            "🔵 蓝色": "#8BE9FD",
            "🟣 紫色": "#BD93F9",
            "🟠 橙色": "#FFB86C"
        }
        color = colors.get(self.highlight_color.currentText(), "#F1FA8C")
        
        self.highlight_words[keyword] = color
        # 使用ExtraSelections更新高亮
        self._update_search_highlights()
        self.highlight_input.clear()
        self.status_label.setText(f"已添加高亮: {keyword}")
    
    def apply_highlights(self):
        """应用高亮 - 使用ExtraSelections"""
        self._update_search_highlights()
    
    def clear_highlights(self):
        """清除所有高亮"""
        self.highlight_words.clear()
        # 使用ExtraSelections更新（会自动清除关键词高亮）
        self._update_search_highlights()
        self.status_label.setText("已清除所有高亮")
    
    def toggle_bookmark(self):
        """切换书签"""
        cursor = self.text_edit.textCursor()
        line_num = cursor.blockNumber() + 1
        
        if line_num in self.bookmarks:
            self.bookmarks.remove(line_num)
            self.status_label.setText(f"已移除书签: 行 {line_num}")
        else:
            self.bookmarks.add(line_num)
            self.status_label.setText(f"已添加书签: 行 {line_num}")
        
        self.update_bookmark_count()
    
    def goto_prev_bookmark(self):
        """跳转到上一个书签"""
        if not self.bookmarks:
            return
        
        current_line = self.text_edit.textCursor().blockNumber() + 1
        prev_bookmarks = [b for b in self.bookmarks if b < current_line]
        
        if prev_bookmarks:
            self._goto_line_internal(max(prev_bookmarks))
        else:
            self._goto_line_internal(max(self.bookmarks))
    
    def goto_next_bookmark(self):
        """跳转到下一个书签"""
        if not self.bookmarks:
            return
        
        current_line = self.text_edit.textCursor().blockNumber() + 1
        next_bookmarks = [b for b in self.bookmarks if b > current_line]
        
        if next_bookmarks:
            self._goto_line_internal(min(next_bookmarks))
        else:
            self._goto_line_internal(min(self.bookmarks))
    
    def clear_all_bookmarks(self):
        """清除所有书签"""
        self.bookmarks.clear()
        self.update_bookmark_count()
        self.status_label.setText("已清除所有书签")
    
    def update_bookmark_count(self):
        """更新书签计数"""
        self.bookmark_count_label.setText(f"书签: {len(self.bookmarks)}")
    
    def show_statistics(self):
        """显示统计信息"""
        if not self.current_file:
            return
        
        # 统计各级别
        level_counts = {}
        time_range = [None, None]
        
        for line_num, content, level, ts in self.original_lines:
            if level:
                level_counts[level] = level_counts.get(level, 0) + 1
            if ts:
                if time_range[0] is None or ts < time_range[0]:
                    time_range[0] = ts
                if time_range[1] is None or ts > time_range[1]:
                    time_range[1] = ts
        
        stats_text = f"""
📊 日志统计

文件: {self.current_file.name}
总行数: {len(self.original_lines)}
文件大小: {self.current_file.size / 1024:.1f} KB

日志级别分布:
"""
        for level, count in sorted(level_counts.items()):
            pct = count / len(self.original_lines) * 100
            stats_text += f"  {level}: {count} ({pct:.1f}%)\n"
        
        if time_range[0] and time_range[1]:
            stats_text += f"\n时间范围:\n  从: {time_range[0]}\n  到: {time_range[1]}"
        
        QMessageBox.information(self, "日志统计", stats_text)
    
    def count_keyword(self):
        """统计关键词出现次数"""
        from PyQt6.QtWidgets import QInputDialog
        keyword, ok = QInputDialog.getText(self, "统计关键词", "输入要统计的关键词:")
        if ok and keyword:
            self.count_selected(keyword)
    
    def count_selected(self, keyword: str):
        """统计选中关键词"""
        text = self.text_edit.toPlainText().lower()
        count = text.count(keyword.lower())
        QMessageBox.information(self, "统计结果", f"关键词 \"{keyword}\" 出现 {count} 次")
    
    def search_selected(self, text: str):
        """搜索选中内容"""
        self.search_input.setText(text)
        self.find_next()
    
    def highlight_selected(self, text: str):
        """高亮选中内容"""
        self.highlight_input.setText(text)
        self.add_highlight()
    
    def copy_file_path(self):
        """复制文件路径"""
        if self.current_file:
            QApplication.clipboard().setText(self.current_file.path)
            self.status_label.setText("已复制文件路径")
    
    def copy_current_line(self):
        """复制当前行"""
        cursor = self.text_edit.textCursor()
        cursor.select(cursor.SelectionType.LineUnderCursor)
        QApplication.clipboard().setText(cursor.selectedText())
        self.status_label.setText("已复制当前行")
    
    def goto_line(self):
        """跳转到指定行"""
        try:
            line_num = int(self.goto_input.text())
            self._goto_line_internal(line_num)
        except ValueError:
            self.status_label.setText("请输入有效的行号")
    
    def _goto_line_internal(self, line_num: int):
        """内部跳转方法"""
        cursor = self.text_edit.textCursor()
        cursor.movePosition(cursor.MoveOperation.Start)
        cursor.movePosition(cursor.MoveOperation.Down, 
                          cursor.MoveMode.MoveAnchor, line_num - 1)
        self.text_edit.setTextCursor(cursor)
        self.text_edit.ensureCursorVisible()
        self.status_label.setText(f"跳转到行 {line_num}")
    
    def highlight_line(self, line_number: int):
        """高亮指定行"""
        cursor = self.text_edit.textCursor()
        cursor.movePosition(cursor.MoveOperation.Start)
        cursor.movePosition(cursor.MoveOperation.Down, 
                          cursor.MoveMode.MoveAnchor, line_number - 1)
        cursor.select(cursor.SelectionType.LineUnderCursor)
        self.text_edit.setTextCursor(cursor)
        self.text_edit.ensureCursorVisible()
    
    def update_cursor_info(self):
        """更新光标位置信息"""
        cursor = self.text_edit.textCursor()
        line = cursor.blockNumber() + 1
        col = cursor.columnNumber() + 1
        self.line_info_label.setText(f"行: {line} | 列: {col}")


class LogPanel(QWidget):
    """单个日志面板"""
    
    line_clicked = pyqtSignal(int, object)  # line_number, timestamp
    sync_requested = pyqtSignal(object)  # timestamp - 请求同步到此时间点
    
    def __init__(self, panel_id: int):
        super().__init__()
        self.panel_id = panel_id
        self.log_file = None
        self.lines_data = []  # [(line_number, content, timestamp), ...]
        self.current_line = 0
        self.current_timestamp = None
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(2)
        
        # 标题栏
        header = QHBoxLayout()
        self.title_label = QLabel(f"日志 {self.panel_id + 1}: 未选择")
        self.title_label.setStyleSheet("font-weight: bold; color: #89b4fa;")
        header.addWidget(self.title_label)
        header.addStretch()
        
        self.close_btn = QPushButton("✖")
        self.close_btn.setMaximumWidth(25)
        self.close_btn.setMaximumHeight(25)
        self.close_btn.setToolTip("移除此日志")
        self.close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                color: #f38ba8;
            }
            QPushButton:hover {
                background-color: #45475a;
            }
        """)
        header.addWidget(self.close_btn)
        
        layout.addLayout(header)
        
        # 日志内容
        self.text_edit = QPlainTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setFont(QFont("Consolas", 10))
        self.text_edit.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.text_edit.setStyleSheet("""
            QPlainTextEdit {
                background-color: #1e1e2e;
                color: #cdd6f4;
                border: 1px solid #45475a;
                border-radius: 3px;
                selection-background-color: #45475a;
            }
        """)
        
        # 右键菜单
        self.text_edit.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.text_edit.customContextMenuRequested.connect(self._show_context_menu)
        
        # 点击事件 - 只更新状态，不自动同步
        self.text_edit.cursorPositionChanged.connect(self._on_cursor_changed)
        
        # 添加语法高亮
        self.highlighter = LogHighlighter(self.text_edit.document())
        
        layout.addWidget(self.text_edit)
        
        # 状态栏
        self.status_label = QLabel("行: - | 时间: -")
        self.status_label.setStyleSheet("color: #a6adc8; font-size: 11px;")
        layout.addWidget(self.status_label)
    
    def _show_context_menu(self, position):
        """显示右键菜单"""
        menu = QMenu(self)
        
        # 同步选项
        sync_action = menu.addAction("🔄 同步其他日志到此时间点")
        sync_action.setEnabled(self.current_timestamp is not None)
        if self.current_timestamp:
            ts_str = self.current_timestamp.strftime('%H:%M:%S')
            sync_action.setText(f"🔄 同步其他日志到此时间点 ({ts_str})")
        
        menu.addSeparator()
        
        # 复制选项
        copy_action = menu.addAction("📋 复制选中内容")
        copy_line_action = menu.addAction("📋 复制当前行")
        
        action = menu.exec(self.text_edit.mapToGlobal(position))
        
        if action == sync_action and self.current_timestamp:
            self.sync_requested.emit(self.current_timestamp)
        elif action == copy_action:
            cursor = self.text_edit.textCursor()
            if cursor.hasSelection():
                QApplication.clipboard().setText(cursor.selectedText())
        elif action == copy_line_action:
            if 0 < self.current_line <= len(self.lines_data):
                _, content, _ = self.lines_data[self.current_line - 1]
                QApplication.clipboard().setText(content)
    
    def load_file(self, log_file: LogFile):
        """加载日志文件"""
        self.log_file = log_file
        self.lines_data = []
        
        # 读取内容
        content_lines = []
        if log_file.entries:
            for entry in log_file.entries:
                self.lines_data.append((entry.line_number, entry.content, entry.timestamp))
                content_lines.append(entry.content)
        else:
            try:
                with open(log_file.path, 'r', encoding=log_file.encoding, errors='replace') as f:
                    for i, line in enumerate(f, 1):
                        line = line.rstrip('\n\r')
                        ts = self._extract_timestamp(line)
                        self.lines_data.append((i, line, ts))
                        content_lines.append(line)
            except Exception as e:
                content_lines = [f"无法读取文件: {e}"]
        
        self.text_edit.setPlainText('\n'.join(content_lines))
        # 显示 test_case/log_folder/name 格式以区分不同目录的同名文件
        self.title_label.setText(f"📄 {log_file.test_case}/{log_file.name}")
        self.title_label.setToolTip(log_file.path)  # 完整路径作为tooltip
        self.status_label.setText(f"共 {len(self.lines_data)} 行")
    
    def _extract_timestamp(self, line: str) -> Optional[datetime]:
        """从行中提取时间戳"""
        import re
        
        patterns = [
            (r'(\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?)', '%Y-%m-%d %H:%M:%S'),
            (r'(\d{4}/\d{2}/\d{2}\s\d{2}:\d{2}:\d{2})', '%Y/%m/%d %H:%M:%S'),
            (r'\[(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})\]', '%Y-%m-%d %H:%M:%S'),
            (r'(\d{2}:\d{2}:\d{2}(?:\.\d+)?)', None),  # 只有时间
        ]
        
        for pattern, fmt in patterns:
            match = re.search(pattern, line)
            if match:
                ts_str = match.group(1).replace('T', ' ')
                try:
                    if fmt:
                        # 处理毫秒
                        if '.' in ts_str and '%f' not in fmt:
                            ts_str = ts_str.split('.')[0]
                        return datetime.strptime(ts_str, fmt)
                    else:
                        # 只有时间，用今天的日期
                        time_str = ts_str.split('.')[0]
                        today = datetime.now().strftime('%Y-%m-%d')
                        return datetime.strptime(f"{today} {time_str}", '%Y-%m-%d %H:%M:%S')
                except:
                    pass
        return None
    
    def _on_cursor_changed(self):
        """光标位置改变 - 只更新状态，不自动同步"""
        cursor = self.text_edit.textCursor()
        line_num = cursor.blockNumber() + 1
        self.current_line = line_num
        
        if 0 < line_num <= len(self.lines_data):
            _, content, timestamp = self.lines_data[line_num - 1]
            self.current_timestamp = timestamp
            
            if timestamp:
                ts_str = timestamp.strftime('%Y-%m-%d %H:%M:%S')
                self.status_label.setText(f"行: {line_num} | 时间: {ts_str}")
            else:
                self.status_label.setText(f"行: {line_num} | 时间: 无")
        else:
            self.current_timestamp = None
    
    def get_current_line_viewport_offset(self) -> int:
        """获取当前行在可视区域中的垂直偏移（像素）"""
        cursor = self.text_edit.textCursor()
        cursor_rect = self.text_edit.cursorRect(cursor)
        return cursor_rect.top()
    
    def goto_line(self, line_number: int):
        """跳转到指定行"""
        if line_number < 1 or line_number > len(self.lines_data):
            return
        
        block = self.text_edit.document().findBlockByLineNumber(line_number - 1)
        cursor = self.text_edit.textCursor()
        cursor.setPosition(block.position())
        self.text_edit.setTextCursor(cursor)
        self.text_edit.ensureCursorVisible()
    
    def goto_line_with_offset(self, line_number: int, target_offset: int):
        """跳转到指定行，并使其在可视区域中处于指定的垂直偏移位置
        
        Args:
            line_number: 目标行号
            target_offset: 目标垂直偏移（像素），即该行应该距离顶部多少像素
        """
        if line_number < 1 or line_number > len(self.lines_data):
            return
        
        # 首先移动光标到目标行
        block = self.text_edit.document().findBlockByLineNumber(line_number - 1)
        cursor = self.text_edit.textCursor()
        cursor.setPosition(block.position())
        self.text_edit.setTextCursor(cursor)
        
        # 获取目标行的文档位置
        cursor_rect = self.text_edit.cursorRect(cursor)
        
        # 计算需要滚动的位置
        scrollbar = self.text_edit.verticalScrollBar()
        current_scroll = scrollbar.value()
        
        # 当前行在视口中的位置
        current_offset = cursor_rect.top()
        
        # 计算需要滚动多少才能让目标行处于target_offset位置
        scroll_adjustment = current_offset - target_offset
        new_scroll = current_scroll + scroll_adjustment
        
        # 确保滚动值在有效范围内
        new_scroll = max(0, min(new_scroll, scrollbar.maximum()))
        
        scrollbar.setValue(int(new_scroll))
    
    def find_nearest_time(self, target_time: datetime) -> Optional[int]:
        """查找最接近目标时间的行号"""
        if not target_time:
            return None
        
        best_line = None
        best_diff = None
        
        for line_num, content, ts in self.lines_data:
            if ts:
                diff = abs((ts - target_time).total_seconds())
                if best_diff is None or diff < best_diff:
                    best_diff = diff
                    best_line = line_num
        
        return best_line
    
    def highlight_line(self, line_number: int, viewport_offset: int = None):
        """高亮指定行
        
        Args:
            line_number: 要高亮的行号
            viewport_offset: 如果指定，则将该行滚动到此垂直偏移位置
        """
        if line_number < 1 or line_number > len(self.lines_data):
            return
        
        if viewport_offset is not None:
            # 跳转并对齐到指定偏移
            self.goto_line_with_offset(line_number, viewport_offset)
        else:
            # 普通跳转
            self.goto_line(line_number)
        
        # 选中整行以高亮
        cursor = self.text_edit.textCursor()
        cursor.movePosition(cursor.MoveOperation.StartOfBlock)
        cursor.movePosition(cursor.MoveOperation.EndOfBlock, cursor.MoveMode.KeepAnchor)
        self.text_edit.setTextCursor(cursor)
    
    def clear_highlight(self):
        """清除高亮"""
        cursor = self.text_edit.textCursor()
        cursor.clearSelection()
        self.text_edit.setTextCursor(cursor)


class MultiLogSyncViewer(QWidget):
    """多日志同步查看器 - 支持2-4个日志文件的时间同步"""
    
    def __init__(self):
        super().__init__()
        self.panels: List[LogPanel] = []
        self.max_panels = 4
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        
        # 工具栏
        toolbar = QHBoxLayout()
        
        toolbar.addWidget(QLabel("📊 多日志同步查看"))
        toolbar.addStretch()
        
        self.add_btn = QPushButton("➕ 添加日志")
        self.add_btn.clicked.connect(self._request_add_log)
        toolbar.addWidget(self.add_btn)
        
        layout.addLayout(toolbar)
        
        # 提示信息
        self.hint_label = QLabel("💡 提示：选中某一行后，右键点击 → 选择「同步其他日志到此时间点」")
        self.hint_label.setStyleSheet("color: #fab387; font-size: 11px; padding: 5px;")
        layout.addWidget(self.hint_label)
        
        # 日志面板容器
        self.panels_splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(self.panels_splitter, 1)
        
        # 空状态提示
        self.empty_label = QLabel('请添加日志文件进行查看\n\n可通过以下方式添加：\n• 点击上方"添加日志"按钮\n• 在文件树中选择多个文件后右键"多日志对比"')
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_label.setStyleSheet("color: #6c7086; font-size: 14px;")
        self.panels_splitter.addWidget(self.empty_label)
    
    def add_log_file(self, log_file: LogFile):
        """添加日志文件"""
        if len(self.panels) >= self.max_panels:
            QMessageBox.warning(self, "提示", f"最多支持 {self.max_panels} 个日志文件")
            return False
        
        # 移除空状态提示
        if self.empty_label.isVisible():
            self.empty_label.hide()
        
        # 创建新面板
        panel = LogPanel(len(self.panels))
        panel.load_file(log_file)
        panel.sync_requested.connect(lambda ts, p=panel: self._on_sync_requested(ts, p))
        panel.close_btn.clicked.connect(lambda: self._remove_panel(panel))
        
        self.panels.append(panel)
        self.panels_splitter.addWidget(panel)
        
        # 更新添加按钮状态
        self._update_add_button()
        
        return True
    
    def _remove_panel(self, panel: LogPanel):
        """移除面板"""
        if panel in self.panels:
            self.panels.remove(panel)
            panel.deleteLater()
            
            # 更新面板ID
            for i, p in enumerate(self.panels):
                p.panel_id = i
            
            # 如果没有面板了，显示空状态
            if not self.panels:
                self.empty_label.show()
            
            self._update_add_button()
    
    def _update_add_button(self):
        """更新添加按钮状态"""
        self.add_btn.setEnabled(len(self.panels) < self.max_panels)
        if len(self.panels) >= self.max_panels:
            self.add_btn.setText(f"已达上限 ({self.max_panels})")
        else:
            self.add_btn.setText(f"➕ 添加日志 ({len(self.panels)}/{self.max_panels})")
    
    def _on_sync_requested(self, timestamp: datetime, source_panel: LogPanel):
        """响应同步请求 - 将其他面板定位到指定时间点，并与源面板对齐"""
        if not timestamp:
            return
        
        # 获取源面板当前行在可视区域的垂直偏移
        source_offset = source_panel.get_current_line_viewport_offset()
        
        synced_count = 0
        for panel in self.panels:
            if panel != source_panel:
                nearest_line = panel.find_nearest_time(timestamp)
                if nearest_line:
                    # 高亮并对齐到与源面板相同的垂直位置
                    panel.highlight_line(nearest_line, viewport_offset=source_offset)
                    synced_count += 1
        
        if synced_count > 0:
            ts_str = timestamp.strftime('%H:%M:%S')
            self.hint_label.setText(f"✅ 已同步 {synced_count} 个日志到时间点 {ts_str}（已对齐显示）")
            self.hint_label.setStyleSheet("color: #a6e3a1; font-size: 11px; padding: 5px;")
            
            # 3秒后恢复提示
            QTimer.singleShot(3000, self._reset_hint)
    
    def _reset_hint(self):
        """恢复默认提示"""
        self.hint_label.setText("💡 提示：选中某一行后，右键点击 → 选择「同步其他日志到此时间点」")
        self.hint_label.setStyleSheet("color: #fab387; font-size: 11px; padding: 5px;")
    
    def _request_add_log(self):
        """请求添加日志（由父窗口处理）"""
        parent = self.parent()
        while parent:
            if hasattr(parent, 'show_add_log_dialog'):
                parent.show_add_log_dialog(self)
                return
            parent = parent.parent()
    
    def load_files(self, log_files: List[LogFile]):
        """批量加载日志文件"""
        # 清除现有面板
        for panel in self.panels[:]:
            self._remove_panel(panel)
        
        # 添加新文件
        for log_file in log_files[:self.max_panels]:
            self.add_log_file(log_file)


# 保留旧的DiffViewerWidget以兼容，但重定向到新组件
class DiffViewerWidget(MultiLogSyncViewer):
    """差异对比查看器 - 已升级为多日志同步查看器"""
    
    def show_diff(self, diff_result):
        """兼容旧的show_diff接口"""
        # 如果传入的是DiffResult，提取文件信息
        if hasattr(diff_result, 'left_file') and hasattr(diff_result, 'right_file'):
            # 需要从外部获取LogFile对象
            pass


class ChatWidget(QWidget):
    """AI对话组件 - 支持目录结构感知和文件分析"""
    
    # 信号：请求打开文件
    request_open_file = pyqtSignal(str)  # file_path
    # 信号：请求定位到行
    request_goto_line = pyqtSignal(str, int)  # file_path, line_number
    
    def __init__(self, ai_indexer: LogAIIndexer):
        super().__init__()
        self.ai_indexer = ai_indexer
        self.chat = None
        
        # 上下文信息
        self.directory_structure = ""  # 目录结构文本
        self.file_list = []  # 文件列表 [(relative_path, full_path, size)]
        self.current_file_path = None  # 当前分析的文件
        self.current_file_content = ""  # 当前文件内容
        self.root_dir = ""  # 根目录
        
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        
        # ============ 顶部工具栏 ============
        header_widget = QWidget()
        header_widget.setStyleSheet("""
            QWidget {
                background-color: #1e1e2e;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        header_layout = QVBoxLayout(header_widget)
        header_layout.setContentsMargins(10, 8, 10, 8)
        header_layout.setSpacing(6)
        
        # 第一行：模型选择
        model_layout = QHBoxLayout()
        
        title_label = QLabel("🤖 AI 日志分析助手")
        title_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #cdd6f4;")
        model_layout.addWidget(title_label)
        
        model_layout.addStretch()
        
        model_label = QLabel("模型:")
        model_label.setStyleSheet("color: #a6adc8;")
        model_layout.addWidget(model_label)
        
        self.model_combo = QComboBox()
        self.model_combo.addItem("qwen3:latest")
        self.model_combo.setStyleSheet("""
            QComboBox {
                padding: 4px 8px;
                border: 1px solid #45475a;
                border-radius: 4px;
                background-color: #313244;
                color: #cdd6f4;
                min-width: 120px;
            }
            QComboBox:hover {
                border-color: #89b4fa;
            }
            QComboBox::drop-down {
                border: none;
            }
        """)
        model_layout.addWidget(self.model_combo)
        
        self.refresh_btn = QPushButton("🔄")
        self.refresh_btn.setMaximumWidth(32)
        self.refresh_btn.setToolTip("刷新模型列表")
        self.refresh_btn.setStyleSheet("""
            QPushButton {
                padding: 4px;
                border: 1px solid #45475a;
                border-radius: 4px;
                background-color: #313244;
            }
            QPushButton:hover {
                background-color: #45475a;
            }
        """)
        self.refresh_btn.clicked.connect(self.refresh_models)
        model_layout.addWidget(self.refresh_btn)
        
        self.status_indicator = QLabel("●")
        self.status_indicator.setStyleSheet("color: gray; font-size: 16px;")
        model_layout.addWidget(self.status_indicator)
        
        header_layout.addLayout(model_layout)
        
        # 分割线
        line1 = QFrame()
        line1.setFrameShape(QFrame.Shape.HLine)
        line1.setStyleSheet("background-color: #45475a;")
        header_layout.addWidget(line1)
        
        # 第二行：上下文信息
        context_layout = QHBoxLayout()
        
        context_icon = QLabel("📁")
        context_layout.addWidget(context_icon)
        
        self.context_label = QLabel("未加载目录")
        self.context_label.setStyleSheet("color: #fab387; font-size: 12px;")
        context_layout.addWidget(self.context_label)
        
        context_layout.addStretch()
        
        self.show_structure_btn = QPushButton("📂 目录结构")
        self.show_structure_btn.setStyleSheet("""
            QPushButton {
                padding: 3px 8px;
                border: 1px solid #45475a;
                border-radius: 4px;
                background-color: transparent;
                color: #89b4fa;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #313244;
            }
            QPushButton:disabled {
                color: #6c7086;
            }
        """)
        self.show_structure_btn.clicked.connect(self.show_directory_structure)
        self.show_structure_btn.setEnabled(False)
        context_layout.addWidget(self.show_structure_btn)
        
        header_layout.addLayout(context_layout)
        
        # 第三行：当前分析文件
        file_layout = QHBoxLayout()
        
        file_icon = QLabel("📄")
        file_layout.addWidget(file_icon)
        
        file_label_static = QLabel("分析文件:")
        file_label_static.setStyleSheet("color: #a6adc8; font-size: 12px;")
        file_layout.addWidget(file_label_static)
        
        self.file_label = QLabel("未选择")
        self.file_label.setStyleSheet("color: #89b4fa; font-size: 12px;")
        self.file_label.setWordWrap(True)
        file_layout.addWidget(self.file_label, 1)
        
        self.clear_file_btn = QPushButton("✖")
        self.clear_file_btn.setMaximumWidth(24)
        self.clear_file_btn.setStyleSheet("""
            QPushButton {
                padding: 2px;
                border: none;
                border-radius: 4px;
                background-color: transparent;
                color: #f38ba8;
            }
            QPushButton:hover {
                background-color: #45475a;
            }
            QPushButton:disabled {
                color: #6c7086;
            }
        """)
        self.clear_file_btn.clicked.connect(self.clear_current_file)
        self.clear_file_btn.setEnabled(False)
        self.clear_file_btn.setToolTip("清除当前分析文件")
        file_layout.addWidget(self.clear_file_btn)
        
        header_layout.addLayout(file_layout)
        
        layout.addWidget(header_widget)
        
        # ============ 对话历史区域 ============
        self.chat_history = QTextEdit()
        self.chat_history.setReadOnly(True)
        self.chat_history.setStyleSheet("""
            QTextEdit {
                background-color: #181825;
                color: #cdd6f4;
                border: 1px solid #313244;
                border-radius: 8px;
                padding: 10px;
                font-size: 13px;
            }
        """)
        # 设置欢迎消息
        self.chat_history.setHtml(self._get_welcome_html())
        layout.addWidget(self.chat_history, 1)
        
        # ============ 快捷问题按钮 ============
        quick_widget = QWidget()
        quick_widget.setStyleSheet("""
            QWidget {
                background-color: #1e1e2e;
                border-radius: 8px;
            }
        """)
        quick_layout = QVBoxLayout(quick_widget)
        quick_layout.setContentsMargins(10, 8, 10, 8)
        quick_layout.setSpacing(6)
        
        quick_title = QLabel("⚡ 快捷操作")
        quick_title.setStyleSheet("color: #a6adc8; font-size: 11px; font-weight: bold;")
        quick_layout.addWidget(quick_title)
        
        # 快捷按钮 - 第一行
        quick_row1 = QHBoxLayout()
        quick_questions1 = [
            ("🔍 查找日志", "请根据目录结构，帮我找到", "#74c7ec"),
            ("❌ 查找错误", "请找出当前日志中所有的ERROR和FATAL级别的错误信息，并分析可能的原因", "#f38ba8"),
            ("📊 分析问题", "请分析当前日志中可能存在的问题和异常", "#fab387"),
        ]
        
        for label, question, color in quick_questions1:
            btn = QPushButton(label)
            btn.setStyleSheet(f"""
                QPushButton {{
                    padding: 6px 12px;
                    border: 1px solid {color};
                    border-radius: 6px;
                    background-color: transparent;
                    color: {color};
                    font-size: 12px;
                }}
                QPushButton:hover {{
                    background-color: {color}30;
                }}
            """)
            btn.clicked.connect(lambda checked, q=question: self._quick_question(q))
            quick_row1.addWidget(btn)
        quick_row1.addStretch()
        quick_layout.addLayout(quick_row1)
        
        # 快捷按钮 - 第二行
        quick_row2 = QHBoxLayout()
        quick_questions2 = [
            ("📅 时间线", "请梳理当前日志中的事件时间线，按时间顺序列出关键事件", "#a6e3a1"),
            ("📈 统计", "请统计当前日志中各级别日志的数量和占比", "#89b4fa"),
            ("💡 建议", "根据日志内容，请给出优化或修复建议", "#cba6f7"),
        ]
        
        for label, question, color in quick_questions2:
            btn = QPushButton(label)
            btn.setStyleSheet(f"""
                QPushButton {{
                    padding: 6px 12px;
                    border: 1px solid {color};
                    border-radius: 6px;
                    background-color: transparent;
                    color: {color};
                    font-size: 12px;
                }}
                QPushButton:hover {{
                    background-color: {color}30;
                }}
            """)
            btn.clicked.connect(lambda checked, q=question: self.send_message(q))
            quick_row2.addWidget(btn)
        quick_row2.addStretch()
        quick_layout.addLayout(quick_row2)
        
        layout.addWidget(quick_widget)
        
        # ============ 输入区域 ============
        input_widget = QWidget()
        input_widget.setStyleSheet("""
            QWidget {
                background-color: #1e1e2e;
                border-radius: 8px;
            }
        """)
        input_main_layout = QVBoxLayout(input_widget)
        input_main_layout.setContentsMargins(10, 8, 10, 8)
        input_main_layout.setSpacing(6)
        
        input_layout = QHBoxLayout()
        
        self.input_text = QLineEdit()
        self.input_text.setPlaceholderText("💬 输入问题，如：帮我找到网络测试的日志 / 分析第50-100行的内容...")
        self.input_text.returnPressed.connect(lambda: self.send_message(self.input_text.text()))
        self.input_text.setStyleSheet("""
            QLineEdit {
                padding: 10px 15px;
                border: 1px solid #45475a;
                border-radius: 8px;
                background-color: #313244;
                color: #cdd6f4;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #89b4fa;
            }
        """)
        input_layout.addWidget(self.input_text)
        
        self.send_btn = QPushButton("发送 ➤")
        self.send_btn.clicked.connect(lambda: self.send_message(self.input_text.text()))
        self.send_btn.setStyleSheet("""
            QPushButton {
                padding: 10px 20px;
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #89b4fa, stop:1 #74c7ec);
                color: #1e1e2e;
                border: none;
                border-radius: 8px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #74c7ec, stop:1 #89dceb);
            }
            QPushButton:pressed {
                background: #89b4fa;
            }
        """)
        input_layout.addWidget(self.send_btn)
        
        self.clear_btn = QPushButton("🗑️")
        self.clear_btn.setMaximumWidth(40)
        self.clear_btn.setToolTip("清除对话历史")
        self.clear_btn.clicked.connect(self.clear_chat)
        self.clear_btn.setStyleSheet("""
            QPushButton {
                padding: 10px;
                border: 1px solid #45475a;
                border-radius: 8px;
                background-color: #313244;
            }
            QPushButton:hover {
                background-color: #f38ba8;
                border-color: #f38ba8;
            }
        """)
        input_layout.addWidget(self.clear_btn)
        
        input_main_layout.addLayout(input_layout)
        
        # 提示文字
        hint_label = QLabel("💡 提示：选择一个日志文件后，AI可以分析其内容；支持指定行号范围，如「分析第50-100行」")
        hint_label.setStyleSheet("color: #6c7086; font-size: 11px;")
        hint_label.setWordWrap(True)
        input_main_layout.addWidget(hint_label)
        
        layout.addWidget(input_widget)
        
        # 初始化时刷新模型列表
        self.refresh_models()
    
    def _get_welcome_html(self) -> str:
        """获取欢迎消息的HTML"""
        return """
        <div style="text-align: center; padding: 40px 20px;">
            <div style="font-size: 48px; margin-bottom: 15px;">🤖</div>
            <div style="font-size: 18px; color: #cdd6f4; font-weight: bold; margin-bottom: 10px;">
                欢迎使用 AI 日志分析助手
            </div>
            <div style="font-size: 13px; color: #a6adc8; line-height: 1.8;">
                我可以帮助你：<br>
                📁 根据目录结构查找日志文件<br>
                🔍 分析日志中的错误和异常<br>
                📊 统计日志级别分布<br>
                📅 梳理事件时间线<br>
                💡 提供问题诊断建议
            </div>
            <div style="margin-top: 20px; padding: 15px; background-color: #313244; border-radius: 8px; text-align: left;">
                <div style="color: #fab387; font-size: 12px; margin-bottom: 8px;">🚀 开始使用：</div>
                <div style="color: #a6adc8; font-size: 12px; line-height: 1.6;">
                    1. 点击「打开目录」加载日志文件<br>
                    2. 双击文件树中的日志文件进行分析<br>
                    3. 使用上方快捷按钮或输入问题
                </div>
            </div>
        </div>
        """
    
    def set_directory_context(self, root_dir: str, log_files: list):
        """设置目录上下文
        
        Args:
            root_dir: 根目录路径
            log_files: LogFile对象列表
        """
        self.root_dir = root_dir
        self.file_list = []
        
        # 构建目录结构
        tree_lines = [f"📁 {Path(root_dir).name}/"]
        
        # 按路径分组构建树结构
        path_dict = {}
        for log_file in log_files:
            rel_path = os.path.relpath(log_file.path, root_dir)
            parts = Path(rel_path).parts
            self.file_list.append((rel_path, log_file.path, log_file.size))
            
            # 构建层级字典
            current = path_dict
            for part in parts[:-1]:
                if part not in current:
                    current[part] = {}
                current = current[part]
            current[parts[-1]] = log_file
        
        def build_tree(d, prefix=""):
            lines = []
            items = list(d.items())
            for i, (name, value) in enumerate(items):
                is_last = i == len(items) - 1
                connector = "└── " if is_last else "├── "
                
                if isinstance(value, dict):
                    lines.append(f"{prefix}{connector}📁 {name}/")
                    extension = "    " if is_last else "│   "
                    lines.extend(build_tree(value, prefix + extension))
                else:
                    # 是文件
                    size_str = self._format_size(value.size)
                    lines.append(f"{prefix}{connector}📄 {name} ({size_str})")
            return lines
        
        tree_lines.extend(build_tree(path_dict))
        self.directory_structure = "\n".join(tree_lines)
        
        # 更新UI
        file_count = len(self.file_list)
        self.context_label.setText(f"{Path(root_dir).name} ({file_count}个日志文件)")
        self.context_label.setStyleSheet("color: #a6e3a1;")
        self.show_structure_btn.setEnabled(True)
        
        # 添加系统消息
        self._append_message("system", f"已加载目录: {Path(root_dir).name}\n共 {file_count} 个日志文件，你可以让AI帮你查找或分析日志。")
    
    def set_current_file(self, file_path: str, content: str = None):
        """设置当前分析的文件
        
        Args:
            file_path: 文件完整路径
            content: 文件内容（可选，如不提供则自动读取）
        """
        self.current_file_path = file_path
        
        if content is None:
            try:
                # 尝试检测编码并读取
                with open(file_path, 'rb') as f:
                    raw = f.read()
                try:
                    import chardet
                    detected = chardet.detect(raw)
                    encoding = detected.get('encoding', 'utf-8')
                except:
                    encoding = 'utf-8'
                self.current_file_content = raw.decode(encoding, errors='replace')
            except Exception as e:
                self.current_file_content = f"[无法读取文件: {e}]"
        else:
            self.current_file_content = content
        
        # 更新UI
        if self.root_dir:
            rel_path = os.path.relpath(file_path, self.root_dir)
        else:
            rel_path = Path(file_path).name
        
        line_count = len(self.current_file_content.splitlines())
        self.file_label.setText(f"{rel_path} ({line_count}行)")
        self.file_label.setStyleSheet("color: #a6e3a1;")
        self.clear_file_btn.setEnabled(True)
        
        # 添加系统消息
        self._append_message("system", f"已选择分析文件: {rel_path}\n共 {line_count} 行，你可以询问关于此文件的问题。")
    
    def clear_current_file(self):
        """清除当前分析文件"""
        self.current_file_path = None
        self.current_file_content = ""
        self.file_label.setText("未选择")
        self.file_label.setStyleSheet("color: #89b4fa;")
        self.clear_file_btn.setEnabled(False)
    
    def show_directory_structure(self):
        """显示目录结构对话框"""
        dialog = QDialog(self)
        dialog.setWindowTitle("目录结构")
        dialog.setMinimumSize(500, 400)
        
        layout = QVBoxLayout(dialog)
        
        text = QTextEdit()
        text.setReadOnly(True)
        text.setPlainText(self.directory_structure)
        text.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e2e;
                color: #cdd6f4;
                font-family: Consolas, monospace;
            }
        """)
        layout.addWidget(text)
        
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(dialog.close)
        layout.addWidget(close_btn)
        
        dialog.exec()
    
    def _format_size(self, size: int) -> str:
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f}{unit}"
            size /= 1024
        return f"{size:.1f}TB"
    
    def _quick_question(self, template: str):
        """处理快捷问题模板"""
        if template.endswith("找到"):
            # 查找日志的模板，需要用户补充
            self.input_text.setText(template + " ")
            self.input_text.setFocus()
        else:
            self.send_message(template)
    
    def refresh_models(self):
        """刷新可用模型列表"""
        models = self.ai_indexer.get_available_models()
        current = self.model_combo.currentText()
        self.model_combo.clear()
        
        if models:
            self.model_combo.addItems(models)
            self.status_indicator.setStyleSheet("color: #a6e3a1;")
            self.status_indicator.setToolTip("Ollama已连接")
            if current in models:
                self.model_combo.setCurrentText(current)
        else:
            self.model_combo.addItem("qwen3:latest")
            self.status_indicator.setStyleSheet("color: #f38ba8;")
            self.status_indicator.setToolTip("Ollama未连接")
    
    def _build_system_prompt(self) -> str:
        """构建系统提示词"""
        prompt_parts = [
            "你是一个专业的测试日志分析助手。你的任务是帮助用户分析和理解测试日志。",
            "",
            "## 你的能力：",
            "1. 根据目录结构帮用户找到特定的测试日志文件",
            "2. 分析日志内容，找出错误、警告和异常",
            "3. 梳理事件时间线",
            "4. 根据用户指定的行号范围展示和分析内容",
            "5. 提供问题诊断和修复建议",
            "",
        ]
        
        # 添加目录结构上下文
        if self.directory_structure:
            prompt_parts.extend([
                "## 当前日志目录结构：",
                "```",
                self.directory_structure,
                "```",
                "",
                "用户可能会让你找某个测试的日志，请根据目录名称和文件名来识别。",
                "当用户让你找某个日志时，请告诉用户完整的相对路径。",
                "",
            ])
        
        # 添加当前文件上下文
        if self.current_file_path and self.current_file_content:
            lines = self.current_file_content.splitlines()
            total_lines = len(lines)
            
            # 如果文件太大，只提供部分内容
            if total_lines > 500:
                # 提供前200行和后100行
                preview_lines = lines[:200] + ["", f"... (省略 {total_lines - 300} 行) ...", ""] + lines[-100:]
                content_preview = "\n".join(preview_lines)
                note = f"（文件共 {total_lines} 行，这里显示前200行和后100行，用户可以指定行号范围让你分析特定部分）"
            else:
                content_preview = self.current_file_content
                note = f"（文件共 {total_lines} 行）"
            
            rel_path = os.path.relpath(self.current_file_path, self.root_dir) if self.root_dir else Path(self.current_file_path).name
            
            prompt_parts.extend([
                f"## 当前分析的文件: {rel_path}",
                note,
                "",
                "文件内容（带行号）：",
                "```",
            ])
            
            # 添加行号
            for i, line in enumerate(content_preview.splitlines(), 1):
                prompt_parts.append(f"{i:5d} | {line}")
            
            prompt_parts.extend([
                "```",
                "",
                "请根据文件内容回答用户的问题。如果用户指定了行号范围，请重点分析该范围的内容。",
                "",
            ])
        
        prompt_parts.extend([
            "## 回答要求：",
            "1. 使用中文回答",
            "2. 如果找到错误或问题，请引用具体的行号和内容",
            "3. 分析要有条理，必要时使用列表",
            "4. 如果用户让你找文件，请给出完整的相对路径",
            "5. 如果需要用户提供更多上下文（如选择具体文件），请明确告知",
        ])
        
        return "\n".join(prompt_parts)
    
    def _extract_line_range(self, message: str) -> tuple:
        """从消息中提取行号范围"""
        import re
        
        # 匹配各种行号范围表达方式
        patterns = [
            r'第?\s*(\d+)\s*[-到至~]\s*(\d+)\s*行',
            r'行\s*(\d+)\s*[-到至~]\s*(\d+)',
            r'(\d+)\s*[-~]\s*(\d+)\s*行',
            r'line[s]?\s*(\d+)\s*[-to~]\s*(\d+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                return int(match.group(1)), int(match.group(2))
        
        # 匹配单行
        single_patterns = [
            r'第\s*(\d+)\s*行',
            r'行\s*(\d+)',
            r'line\s*(\d+)',
        ]
        
        for pattern in single_patterns:
            match = re.search(pattern, message, re.IGNORECASE)
            if match:
                line = int(match.group(1))
                return line, line
        
        return None, None
    
    def _get_file_content_range(self, start: int, end: int) -> str:
        """获取指定行范围的内容"""
        if not self.current_file_content:
            return ""
        
        lines = self.current_file_content.splitlines()
        start = max(1, start)
        end = min(len(lines), end)
        
        result = []
        for i in range(start - 1, end):
            result.append(f"{i + 1:5d} | {lines[i]}")
        
        return "\n".join(result)
    
    def send_message(self, message: str):
        """发送消息"""
        if not message.strip():
            return
        
        self.input_text.clear()
        
        # 显示用户消息
        self._append_message("user", message)
        
        # 显示加载状态
        self._append_message("system", "正在思考...")
        
        # 检查是否需要提取行号范围
        start_line, end_line = self._extract_line_range(message)
        
        # 构建完整的消息
        full_message = message
        if start_line and end_line and self.current_file_content:
            range_content = self._get_file_content_range(start_line, end_line)
            full_message = f"{message}\n\n以下是第 {start_line} 到 {end_line} 行的内容：\n```\n{range_content}\n```"
        
        # 创建或更新chat实例
        model = self.model_combo.currentText()
        if self.chat is None or self.chat.model_name != model:
            self.chat = OllamaChat(model_name=model)
            self.chat.clear_history()
        
        # 设置系统提示词
        system_prompt = self._build_system_prompt()
        
        # 在后台线程中处理
        def get_response():
            return self.chat.chat(full_message, system_prompt=system_prompt)
        
        self.worker = WorkerThread(get_response)
        self.worker.finished.connect(self._on_response)
        self.worker.error.connect(self._on_error)
        self.worker.start()
    
    def _on_response(self, response: str):
        """处理响应"""
        # 移除"正在思考..."
        cursor = self.chat_history.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        cursor.movePosition(cursor.MoveOperation.StartOfBlock, 
                          cursor.MoveMode.KeepAnchor)
        cursor.removeSelectedText()
        cursor.deletePreviousChar()
        
        # 显示AI响应
        self._append_message("assistant", response)
        
        # 检查响应中是否有文件路径，如果有则添加操作按钮
        found_files = self._find_files_in_response(response)
        if found_files:
            self._add_file_buttons(found_files)
    
    def _find_files_in_response(self, response: str) -> List[tuple]:
        """在响应中查找匹配的文件路径"""
        found = []
        if not self.file_list:
            return found
        
        for rel_path, full_path, size in self.file_list:
            # 检查相对路径或文件名是否在响应中
            if rel_path in response or Path(rel_path).name in response:
                if (rel_path, full_path) not in [(f[0], f[1]) for f in found]:
                    found.append((rel_path, full_path, size))
        
        return found
    
    def _add_file_buttons(self, files: List[tuple]):
        """添加文件操作按钮"""
        if not files:
            return
        
        # 创建按钮容器
        button_widget = QWidget()
        button_layout = QHBoxLayout(button_widget)
        button_layout.setContentsMargins(20, 5, 5, 5)
        button_layout.setSpacing(5)
        
        label = QLabel("📁 找到的文件：")
        label.setStyleSheet("color: #89b4fa;")
        button_layout.addWidget(label)
        
        for rel_path, full_path, size in files[:3]:  # 最多显示3个
            file_name = Path(rel_path).name
            
            # 打开按钮
            open_btn = QPushButton(f"📂 {file_name}")
            open_btn.setToolTip(f"打开文件: {rel_path}")
            open_btn.setStyleSheet("""
                QPushButton {
                    padding: 4px 8px;
                    background-color: #45475a;
                    border: none;
                    border-radius: 3px;
                    color: #cdd6f4;
                    font-size: 11px;
                }
                QPushButton:hover {
                    background-color: #585b70;
                }
            """)
            open_btn.clicked.connect(lambda checked, p=full_path: self._open_file(p))
            button_layout.addWidget(open_btn)
            
            # 分析按钮
            analyze_btn = QPushButton("🤖 分析")
            analyze_btn.setToolTip(f"让AI分析此文件")
            analyze_btn.setStyleSheet("""
                QPushButton {
                    padding: 4px 8px;
                    background-color: #89b4fa;
                    border: none;
                    border-radius: 3px;
                    color: #1e1e2e;
                    font-size: 11px;
                }
                QPushButton:hover {
                    background-color: #74c7ec;
                }
            """)
            analyze_btn.clicked.connect(lambda checked, p=full_path: self._analyze_file(p))
            button_layout.addWidget(analyze_btn)
        
        button_layout.addStretch()
        
        # 将按钮添加到聊天历史底部
        cursor = self.chat_history.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        
        # 插入一个占位符
        self.chat_history.setTextCursor(cursor)
        
        # 使用QTextEdit的append来添加widget不太方便，改用文本链接
        # 改为在消息中添加可识别的标记，然后用按钮区域
        self._file_buttons_widget = button_widget
        
        # 直接在chat_history下方显示按钮（需要修改布局）
        # 这里简化处理：在父布局中添加按钮
        parent_layout = self.layout()
        if parent_layout:
            # 移除旧的按钮widget
            if hasattr(self, '_last_file_buttons') and self._last_file_buttons:
                self._last_file_buttons.deleteLater()
            
            # 在chat_history后面插入
            idx = parent_layout.indexOf(self.chat_history)
            if idx >= 0:
                parent_layout.insertWidget(idx + 1, button_widget)
                self._last_file_buttons = button_widget
    
    def _open_file(self, file_path: str):
        """打开文件"""
        self.request_open_file.emit(file_path)
    
    def _analyze_file(self, file_path: str):
        """分析文件"""
        # 先打开文件
        self.request_open_file.emit(file_path)
        
        # 设置为当前分析文件
        try:
            with open(file_path, 'rb') as f:
                raw = f.read()
            try:
                import chardet
                detected = chardet.detect(raw)
                encoding = detected.get('encoding', 'utf-8')
            except:
                encoding = 'utf-8'
            content = raw.decode(encoding, errors='replace')
            self.set_current_file(file_path, content)
            
            # 自动发送分析请求
            QTimer.singleShot(500, lambda: self.send_message(
                "请分析这个日志文件，找出所有的错误、警告和潜在问题，并给出修复建议。"
            ))
        except Exception as e:
            self._append_message("error", f"无法读取文件: {e}")
    
    def _on_error(self, error: str):
        """处理错误"""
        cursor = self.chat_history.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        cursor.movePosition(cursor.MoveOperation.StartOfBlock, 
                          cursor.MoveMode.KeepAnchor)
        cursor.removeSelectedText()
        
        self._append_message("error", f"错误: {error}")
    
    def _append_message(self, role: str, content: str):
        """添加消息到历史 - 使用美观的气泡样式"""
        
        # 配置不同角色的样式
        styles = {
            "user": {
                "bg": "#313244",
                "border": "#45475a", 
                "icon": "👤",
                "label": "你",
                "label_color": "#89b4fa",
                "align": "right",
            },
            "assistant": {
                "bg": "#1e3a29",
                "border": "#2d5a3d",
                "icon": "🤖",
                "label": "AI 助手",
                "label_color": "#a6e3a1",
                "align": "left",
            },
            "system": {
                "bg": "#2d2a1e",
                "border": "#4a4630",
                "icon": "⏳",
                "label": "系统",
                "label_color": "#fab387",
                "align": "center",
            },
            "error": {
                "bg": "#3d1e1e",
                "border": "#5a2d2d",
                "icon": "❌",
                "label": "错误",
                "label_color": "#f38ba8",
                "align": "left",
            }
        }
        
        style = styles.get(role, styles["assistant"])
        
        # 转义HTML特殊字符并处理换行和代码块
        safe_content = content.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        
        # 处理代码块 ```
        import re
        code_block_pattern = r'```(\w*)\n?(.*?)```'
        
        def replace_code_block(match):
            lang = match.group(1)
            code = match.group(2).strip()
            code_html = code.replace('\n', '<br>').replace(' ', '&nbsp;')
            return f'''<div style="background-color: #11111b; border: 1px solid #313244; 
                        border-radius: 6px; padding: 10px; margin: 8px 0; 
                        font-family: Consolas, monospace; font-size: 12px; 
                        overflow-x: auto; color: #cdd6f4;">
                        {code_html}</div>'''
        
        safe_content = re.sub(code_block_pattern, replace_code_block, safe_content, flags=re.DOTALL)
        
        # 处理普通换行
        safe_content = safe_content.replace('\n', '<br>')
        
        # 处理行内代码 `code`
        safe_content = re.sub(r'`([^`]+)`', 
            r'<code style="background-color: #45475a; padding: 2px 6px; border-radius: 4px; font-family: Consolas, monospace;">\1</code>', 
            safe_content)
        
        # 处理加粗 **text**
        safe_content = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', safe_content)
        
        # 根据对齐方式生成不同的HTML
        if style["align"] == "right":
            # 用户消息 - 右对齐
            html = f'''
            <div style="margin: 12px 0; text-align: right;">
                <div style="display: inline-block; max-width: 85%; text-align: left;">
                    <div style="font-size: 11px; color: {style['label_color']}; margin-bottom: 4px;">
                        {style['label']} {style['icon']}
                    </div>
                    <div style="background-color: {style['bg']}; border: 1px solid {style['border']};
                                border-radius: 12px 12px 4px 12px; padding: 12px 15px;
                                color: #cdd6f4; font-size: 13px; line-height: 1.5;">
                        {safe_content}
                    </div>
                </div>
            </div>
            '''
        elif style["align"] == "center":
            # 系统消息 - 居中
            html = f'''
            <div style="margin: 8px 0; text-align: center;">
                <span style="background-color: {style['bg']}; border: 1px solid {style['border']};
                            border-radius: 15px; padding: 6px 15px; 
                            color: {style['label_color']}; font-size: 12px;">
                    {style['icon']} {safe_content}
                </span>
            </div>
            '''
        else:
            # AI消息 - 左对齐
            html = f'''
            <div style="margin: 12px 0;">
                <div style="display: inline-block; max-width: 85%;">
                    <div style="font-size: 11px; color: {style['label_color']}; margin-bottom: 4px;">
                        {style['icon']} {style['label']}
                    </div>
                    <div style="background-color: {style['bg']}; border: 1px solid {style['border']};
                                border-radius: 12px 12px 12px 4px; padding: 12px 15px;
                                color: #cdd6f4; font-size: 13px; line-height: 1.6;">
                        {safe_content}
                    </div>
                </div>
            </div>
            '''
        
        cursor = self.chat_history.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        cursor.insertHtml(html)
        
        # 滚动到底部
        scrollbar = self.chat_history.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
    
    def clear_chat(self):
        """清除对话"""
        self.chat_history.setHtml(self._get_welcome_html())
        if self.chat:
            self.chat.clear_history()


class SearchResultsWidget(QWidget):
    """搜索结果组件"""
    
    result_clicked = pyqtSignal(str, int)  # file_path, line_number
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        self.results_list = QListWidget()
        self.results_list.itemDoubleClicked.connect(self._on_item_clicked)
        self.results_list.setStyleSheet("""
            QListWidget {
                background-color: #1e1e2e;
                color: #cdd6f4;
                border: none;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #313244;
            }
            QListWidget::item:selected {
                background-color: #45475a;
            }
            QListWidget::item:hover {
                background-color: #313244;
            }
        """)
        layout.addWidget(self.results_list)
    
    def show_results(self, results: List[LogSearchResult]):
        """显示搜索结果"""
        self.results_list.clear()
        
        for result in results:
            entry = result.entry
            text = f"📍 行 {entry.line_number} | {Path(entry.file_path).name}\n"
            text += f"   {entry.content[:100]}..."
            
            item = QListWidgetItem(text)
            item.setData(Qt.ItemDataRole.UserRole, (entry.file_path, entry.line_number))
            
            # 根据日志级别设置颜色
            if entry.level:
                colors = {
                    'ERROR': QColor('#f38ba8'),
                    'FATAL': QColor('#f38ba8'),
                    'WARN': QColor('#fab387'),
                    'INFO': QColor('#a6e3a1'),
                    'DEBUG': QColor('#89b4fa'),
                }
                color = colors.get(entry.level.upper(), QColor('#cdd6f4'))
                item.setForeground(color)
            
            self.results_list.addItem(item)
    
    def _on_item_clicked(self, item: QListWidgetItem):
        """点击结果项"""
        data = item.data(Qt.ItemDataRole.UserRole)
        if data:
            file_path, line_number = data
            self.result_clicked.emit(file_path, line_number)


class SettingsDialog(QDialog):
    """设置对话框"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("设置")
        self.setMinimumWidth(400)
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Ollama设置
        ollama_group = QGroupBox("Ollama设置")
        ollama_layout = QFormLayout()
        
        self.ollama_url = QLineEdit("http://localhost:11434")
        ollama_layout.addRow("服务地址:", self.ollama_url)
        
        self.default_model = QComboBox()
        self.default_model.addItems(["qwen3:latest", "llama3:latest", "mistral:latest"])
        self.default_model.setEditable(True)
        ollama_layout.addRow("默认模型:", self.default_model)
        
        ollama_group.setLayout(ollama_layout)
        layout.addWidget(ollama_group)
        
        # 日志解析设置
        parse_group = QGroupBox("日志解析设置")
        parse_layout = QFormLayout()
        
        self.max_lines = QSpinBox()
        self.max_lines.setRange(1000, 1000000)
        self.max_lines.setValue(100000)
        parse_layout.addRow("最大行数:", self.max_lines)
        
        self.auto_parse = QCheckBox()
        self.auto_parse.setChecked(True)
        parse_layout.addRow("自动解析时间戳:", self.auto_parse)
        
        parse_group.setLayout(parse_layout)
        layout.addWidget(parse_group)
        
        # 界面设置
        ui_group = QGroupBox("界面设置")
        ui_layout = QFormLayout()
        
        self.font_size = QSpinBox()
        self.font_size.setRange(8, 24)
        self.font_size.setValue(10)
        ui_layout.addRow("字体大小:", self.font_size)
        
        self.theme = QComboBox()
        self.theme.addItems(["暗色", "亮色"])
        ui_layout.addRow("主题:", self.theme)
        
        ui_group.setLayout(ui_layout)
        layout.addWidget(ui_group)
        
        # 按钮
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | 
            QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
